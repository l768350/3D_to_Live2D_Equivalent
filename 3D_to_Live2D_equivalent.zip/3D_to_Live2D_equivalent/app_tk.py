# -*- coding: utf-8 -*-
"""
app_tk.py
----------
Inochi2D OBJ Deformer 的桌面版GUI(tkinter，Python标准库自带，除了numpy/pillow
不需要额外装东西)。跟app.py(Streamlit网页版)功能一致，换成一个紧凑的原生窗口——
所有控件都在一个不用滚动的窗口里，选文件用系统原生对话框。核心计算逻辑复用同一份
gui_core.py，跟网页版是同一套后端，不用改两遍。

运行：
    python3 app_tk.py
"""
import os
import sys
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gui_core as gc
from obj_head_model import rotate_verts_deg

DEFAULTS = {
    "cage_method": "cylinder",
    "node_type": "meshgroup",
    "group_by": "object",
    "scale": "3000",
    "cols": "26",
    "rows": "",            # 空=自动
    "expand_frac": "0.15",
    "ray_radius": "",      # 空=自动
    "radius_margin": "1.3",
    "facing": "front",
    "z_threshold": "-0.04",
    "texel_density": "",   # 空=自动
    "yaw_range": "40",
    "pitch_range": "25",
    "roll_range": "15",
    "yaw_bp": "9",
    "pitch_bp": "5",
    "roll_bp": "5",
}
CAGE_METHODS = ["cylinder", "full-topology", "full-topology-uv"]
GROUP_BYS = ["object", "material", "object_material"]
DIRS = ["both", "neg", "pos"]
FACINGS = ["front", "back"]


class App:
    def __init__(self, root):
        self.root = root
        root.title("3D_to_Live2D_equivalent")
        root.geometry("1180x760")

        self.state = {
            "obj_path": None, "obj_display_name": None,
            "texture_bytes": None,
            "doc": None,
            "global_rotate": (0.0, 0.0, 0.0), "y_center": 0.0,
            "parts_cache_key": None, "parts_cache": {},
            "cur_verts": None, "cur_faces": None, "cur_uvs": None,
            "turn_params": [], "roll_params": [],
        }
        self._part_names = ["(整个OBJ，不拆分)"]
        self.pv = {k: tk.StringVar(value=v) for k, v in DEFAULTS.items()}

        self._build_ui()
        self._on_cage_method_change()

    # ------------------------------------------------------------------
    # UI构建
    # ------------------------------------------------------------------
    def _build_ui(self):
        pad = dict(padx=4, pady=3)
        root = self.root
        root.columnconfigure(0, weight=1)
        root.rowconfigure(2, weight=1)

        f_import = ttk.LabelFrame(root, text="导入")
        f_import.grid(row=0, column=0, sticky="ew", **pad)
        self.lbl_obj = ttk.Label(f_import, text="(未选择OBJ)", width=26, anchor="w")
        self.lbl_inx = ttk.Label(f_import, text="(未选择，新建)", width=20, anchor="w")
        self.lbl_tex = ttk.Label(f_import, text="(未选择)", width=16, anchor="w")
        ttk.Button(f_import, text="选OBJ", command=self.browse_obj).grid(row=0, column=0, **pad)
        self.lbl_obj.grid(row=0, column=1, **pad)
        ttk.Button(f_import, text="选已有inx(可选)", command=self.browse_inx).grid(row=0, column=2, **pad)
        self.lbl_inx.grid(row=0, column=3, **pad)
        ttk.Button(f_import, text="选贴图(可选)", command=self.browse_tex).grid(row=0, column=4, **pad)
        self.lbl_tex.grid(row=0, column=5, **pad)
        ttk.Button(f_import, text="导入 / (重新)开始会话", command=self.do_import).grid(row=0, column=6, **pad)
        self.lbl_status = ttk.Label(f_import, text="", foreground="#0a6")
        self.lbl_status.grid(row=0, column=7, **pad)

        f_rot = ttk.LabelFrame(root, text="调整初始模型(全局、一次性——转动动画参照系也会跟着变)")
        f_rot.grid(row=1, column=0, sticky="ew", **pad)
        ttk.Label(f_rot, text="X°").grid(row=0, column=0, **pad)
        self.e_grx = ttk.Entry(f_rot, width=6); self.e_grx.insert(0, "0"); self.e_grx.grid(row=0, column=1, **pad)
        ttk.Label(f_rot, text="Y°").grid(row=0, column=2, **pad)
        self.e_gry = ttk.Entry(f_rot, width=6); self.e_gry.insert(0, "0"); self.e_gry.grid(row=0, column=3, **pad)
        ttk.Label(f_rot, text="Z°").grid(row=0, column=4, **pad)
        self.e_grz = ttk.Entry(f_rot, width=6); self.e_grz.insert(0, "0"); self.e_grz.grid(row=0, column=5, **pad)
        ttk.Button(f_rot, text="应用初始旋转", command=self.apply_global_rotate).grid(row=0, column=6, **pad)
        self.lbl_ycenter = ttk.Label(f_rot, text="y_center_obj = 0.0000")
        self.lbl_ycenter.grid(row=0, column=7, **pad)

        f_main = ttk.Frame(root)
        f_main.grid(row=2, column=0, sticky="nsew", **pad)
        f_main.columnconfigure(0, weight=1)
        f_main.columnconfigure(1, weight=1)
        f_main.columnconfigure(2, weight=1)
        f_main.rowconfigure(0, weight=1)
        self._build_params_panel(f_main)
        self._build_parts_panel(f_main)
        self._build_deformers_panel(f_main)

        self._build_write_panel(root, row=3)
        self._build_export_panel(root, row=4)

    def _build_params_panel(self, parent):
        f = ttk.LabelFrame(parent, text="参数")
        f.grid(row=0, column=0, sticky="nsew", padx=4, pady=3)
        ttk.Button(f, text="重置为默认值", command=self.reset_params).grid(
            row=0, column=0, columnspan=2, sticky="ew", padx=2, pady=2)

        self._r = 1

        def label_row(text, widget_factory):
            row = self._r
            ttk.Label(f, text=text).grid(row=row, column=0, sticky="w", padx=2)
            w = widget_factory()
            w.grid(row=row, column=1, padx=2, pady=1, sticky="w")
            self._r += 1
            return w

        self.cb_cage = label_row("笼子构筑方式", lambda: ttk.Combobox(
            f, values=CAGE_METHODS, textvariable=self.pv["cage_method"], state="readonly", width=16))
        self.cb_cage.bind("<<ComboboxSelected>>", self._on_cage_method_change)

        self.cb_node = label_row("节点类型", lambda: ttk.Combobox(
            f, values=["meshgroup", "part"], textvariable=self.pv["node_type"], state="readonly", width=16))

        self.cb_group = label_row("分组方式(--group-by)", lambda: ttk.Combobox(
            f, values=GROUP_BYS, textvariable=self.pv["group_by"], state="readonly", width=16))
        self.cb_group.bind("<<ComboboxSelected>>", lambda e: self.refresh_parts())

        label_row("scale", lambda: ttk.Entry(f, textvariable=self.pv["scale"], width=10))

        self.f_cyl = ttk.Frame(f)
        self.f_cyl.grid(row=self._r, column=0, columnspan=2, sticky="ew"); self._r += 1
        rr = 0
        for lbl, key in [("cols", "cols"), ("rows(空=自动)", "rows"), ("expand_frac", "expand_frac"),
                          ("ray_radius(空=自动)", "ray_radius"), ("radius_margin", "radius_margin")]:
            ttk.Label(self.f_cyl, text=lbl).grid(row=rr, column=0, sticky="w", padx=2)
            ttk.Entry(self.f_cyl, textvariable=self.pv[key], width=10).grid(row=rr, column=1, padx=2, pady=1, sticky="w")
            rr += 1

        self.f_ft = ttk.Frame(f)
        self.f_ft.grid(row=self._r, column=0, columnspan=2, sticky="ew"); self._r += 1
        ttk.Label(self.f_ft, text="facing").grid(row=0, column=0, sticky="w", padx=2)
        ttk.Combobox(self.f_ft, values=FACINGS, textvariable=self.pv["facing"],
                     state="readonly", width=8).grid(row=0, column=1, padx=2, sticky="w")
        ttk.Label(self.f_ft, text="z_threshold").grid(row=1, column=0, sticky="w", padx=2)
        ttk.Entry(self.f_ft, textvariable=self.pv["z_threshold"], width=10).grid(row=1, column=1, padx=2, sticky="w")

        self.f_uv = ttk.Frame(f)
        self.f_uv.grid(row=self._r, column=0, columnspan=2, sticky="ew"); self._r += 1
        ttk.Label(self.f_uv, text="texel_density(空=自动)").grid(row=0, column=0, sticky="w", padx=2)
        ttk.Entry(self.f_uv, textvariable=self.pv["texel_density"], width=10).grid(row=0, column=1, padx=2, sticky="w")

        ttk.Separator(f, orient="horizontal").grid(row=self._r, column=0, columnspan=2, sticky="ew", pady=4)
        self._r += 1
        ttk.Label(f, text="Turn/Roll幅度+断点(新建时用；绑定已有时断点数自动复用目标)",
                  wraplength=220, font=("", 8)).grid(row=self._r, column=0, columnspan=2, sticky="w", padx=2)
        self._r += 1
        label_row("yaw_range°", lambda: ttk.Entry(f, textvariable=self.pv["yaw_range"], width=10))
        label_row("pitch_range°", lambda: ttk.Entry(f, textvariable=self.pv["pitch_range"], width=10))
        self.e_roll_range = label_row("roll_range°", lambda: ttk.Entry(f, textvariable=self.pv["roll_range"], width=10))
        label_row("yaw_bp", lambda: ttk.Entry(f, textvariable=self.pv["yaw_bp"], width=10))
        label_row("pitch_bp", lambda: ttk.Entry(f, textvariable=self.pv["pitch_bp"], width=10))
        self.e_roll_bp = label_row("roll_bp", lambda: ttk.Entry(f, textvariable=self.pv["roll_bp"], width=10))

    def _build_parts_panel(self, parent):
        f = ttk.LabelFrame(parent, text="OBJ 部件")
        f.grid(row=0, column=1, sticky="nsew", padx=4, pady=3)
        f.rowconfigure(0, weight=1)
        f.columnconfigure(0, weight=1)

        self.lb_parts = tk.Listbox(f, exportselection=False, height=14)
        self.lb_parts.grid(row=0, column=0, sticky="nsew", padx=2, pady=2)
        sb = ttk.Scrollbar(f, orient="vertical", command=self.lb_parts.yview)
        sb.grid(row=0, column=1, sticky="ns")
        self.lb_parts.configure(yscrollcommand=sb.set)
        self.lb_parts.bind("<<ListboxSelect>>", self._on_part_select)

        self.lbl_part_info = ttk.Label(f, text="顶点数: -  三角面数: -")
        self.lbl_part_info.grid(row=1, column=0, columnspan=2, sticky="w", padx=2)

        ttk.Button(f, text="诊断碎片化(UV island连通性)", command=self.do_diagnose).grid(
            row=2, column=0, columnspan=2, sticky="ew", padx=2, pady=2)
        self.txt_diag = tk.Text(f, height=8, width=36, wrap="word")
        self.txt_diag.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=2, pady=2)

    def _build_deformers_panel(self, parent):
        f = ttk.LabelFrame(parent, text="已有 Deformer")
        f.grid(row=0, column=2, sticky="nsew", padx=4, pady=3)
        f.columnconfigure(0, weight=1)
        f.rowconfigure(1, weight=1)
        f.rowconfigure(3, weight=1)
        f.rowconfigure(5, weight=1)

        ttk.Label(f, text="Turn(yaw+pitch)：").grid(row=0, column=0, sticky="w", padx=2)
        self.lb_turn = tk.Listbox(f, exportselection=False, height=5)
        self.lb_turn.grid(row=1, column=0, sticky="nsew", padx=2, pady=2)

        ttk.Label(f, text="Roll：").grid(row=2, column=0, sticky="w", padx=2)
        self.lb_roll = tk.Listbox(f, exportselection=False, height=5)
        self.lb_roll.grid(row=3, column=0, sticky="nsew", padx=2, pady=2)

        ttk.Label(f, text="节点树：").grid(row=4, column=0, sticky="w", padx=2)
        self.lb_nodes = tk.Listbox(f, exportselection=False, height=5)
        self.lb_nodes.grid(row=5, column=0, sticky="nsew", padx=2, pady=2)

    def _build_write_panel(self, parent, row):
        f = ttk.LabelFrame(parent, text="写入操作")
        f.grid(row=row, column=0, sticky="ew", padx=4, pady=3)

        ttk.Label(f, text="节点/参数名").grid(row=0, column=0, sticky="w", padx=2)
        self.e_name = ttk.Entry(f, width=18)
        self.e_name.grid(row=0, column=1, padx=2, pady=2)

        ttk.Label(f, text="挂载到").grid(row=0, column=2, sticky="w", padx=2)
        self.cb_parent = ttk.Combobox(f, values=["(Root)"], state="readonly", width=14)
        self.cb_parent.set("(Root)")
        self.cb_parent.grid(row=0, column=3, padx=2, pady=2)

        self.f_cage_rot = ttk.Frame(f)
        self.f_cage_rot.grid(row=0, column=4, columnspan=8, sticky="w")
        ttk.Label(self.f_cage_rot, text="笼子朝向(仅本次操作):").grid(row=0, column=0, padx=2)
        ttk.Button(self.f_cage_rot, text="前", width=3, command=lambda: self._set_cage_rot_y(0)).grid(row=0, column=1)
        ttk.Button(self.f_cage_rot, text="后", width=3, command=lambda: self._set_cage_rot_y(180)).grid(row=0, column=2)
        ttk.Button(self.f_cage_rot, text="左", width=3, command=lambda: self._set_cage_rot_y(90)).grid(row=0, column=3)
        ttk.Button(self.f_cage_rot, text="右", width=3, command=lambda: self._set_cage_rot_y(-90)).grid(row=0, column=4)
        ttk.Label(self.f_cage_rot, text="X").grid(row=0, column=5)
        self.e_cage_rx = ttk.Entry(self.f_cage_rot, width=5); self.e_cage_rx.insert(0, "0")
        self.e_cage_rx.grid(row=0, column=6)
        ttk.Label(self.f_cage_rot, text="Y").grid(row=0, column=7)
        self.e_cage_ry = ttk.Entry(self.f_cage_rot, width=5); self.e_cage_ry.insert(0, "0")
        self.e_cage_ry.grid(row=0, column=8)
        ttk.Label(self.f_cage_rot, text="Z").grid(row=0, column=9)
        self.e_cage_rz = ttk.Entry(self.f_cage_rot, width=5); self.e_cage_rz.insert(0, "0")
        self.e_cage_rz.grid(row=0, column=10)

        self.var_turn_on = tk.BooleanVar(value=True)
        ttk.Checkbutton(f, text="生成/绑定Turn", variable=self.var_turn_on).grid(row=1, column=0, sticky="w", padx=2, pady=2)
        self.cb_turn_target = ttk.Combobox(f, values=["(新建)"], state="readonly", width=16)
        self.cb_turn_target.set("(新建)")
        self.cb_turn_target.grid(row=1, column=1, padx=2, pady=2)
        ttk.Label(f, text="yaw方向").grid(row=1, column=2, sticky="w", padx=2)
        self.cb_yaw_dir = ttk.Combobox(f, values=DIRS, state="readonly", width=6)
        self.cb_yaw_dir.set("both")
        self.cb_yaw_dir.grid(row=1, column=3, padx=2, pady=2)
        ttk.Label(f, text="pitch方向").grid(row=1, column=4, sticky="w", padx=2)
        self.cb_pitch_dir = ttk.Combobox(f, values=DIRS, state="readonly", width=6)
        self.cb_pitch_dir.set("both")
        self.cb_pitch_dir.grid(row=1, column=5, padx=2, pady=2)

        self.var_roll_on = tk.BooleanVar(value=True)
        self.cb_roll_on = ttk.Checkbutton(f, text="生成/绑定Roll", variable=self.var_roll_on)
        self.cb_roll_on.grid(row=2, column=0, sticky="w", padx=2, pady=2)
        self.cb_roll_target = ttk.Combobox(f, values=["(新建)"], state="readonly", width=16)
        self.cb_roll_target.set("(新建)")
        self.cb_roll_target.grid(row=2, column=1, padx=2, pady=2)
        ttk.Label(f, text="roll方向").grid(row=2, column=2, sticky="w", padx=2)
        self.cb_roll_dir = ttk.Combobox(f, values=DIRS, state="readonly", width=6)
        self.cb_roll_dir.set("both")
        self.cb_roll_dir.grid(row=2, column=3, padx=2, pady=2)
        self.lbl_roll_note = ttk.Label(f, text="", foreground="#a60")
        self.lbl_roll_note.grid(row=2, column=4, columnspan=4, sticky="w", padx=2)

        ttk.Button(f, text="✅ 确认写入这个部件", command=self.do_write).grid(
            row=1, column=6, rowspan=2, padx=8, pady=2, sticky="ns")

    def _build_export_panel(self, parent, row):
        f = ttk.LabelFrame(parent, text="导出")
        f.grid(row=row, column=0, sticky="ew", padx=4, pady=3)
        f.columnconfigure(0, weight=1)
        self.e_save_path = ttk.Entry(f)
        self.e_save_path.grid(row=0, column=0, padx=2, pady=2, sticky="ew")
        ttk.Button(f, text="浏览另存为...", command=self.browse_save_as).grid(row=0, column=1, padx=2)
        ttk.Button(f, text="💾 保存到这个路径", command=self.do_save).grid(row=0, column=2, padx=2)
        self.lbl_save_status = ttk.Label(f, text="")
        self.lbl_save_status.grid(row=1, column=0, columnspan=3, sticky="w", padx=2)

    # ------------------------------------------------------------------
    # 导入 / 全局旋转
    # ------------------------------------------------------------------
    def browse_obj(self):
        path = filedialog.askopenfilename(title="选择OBJ", filetypes=[("OBJ files", "*.obj"), ("All files", "*.*")])
        if path:
            self._pending_obj = path
            self.lbl_obj.config(text=os.path.basename(path))

    def browse_inx(self):
        path = filedialog.askopenfilename(title="选择已有inx(可选)",
                                           filetypes=[("Inochi2D files", "*.inx *.inp"), ("All files", "*.*")])
        if path:
            self._pending_inx = path
            self.lbl_inx.config(text=os.path.basename(path))

    def browse_tex(self):
        path = filedialog.askopenfilename(title="选择贴图(可选)",
                                           filetypes=[("PNG files", "*.png"), ("All files", "*.*")])
        if path:
            self._pending_tex = path
            self.lbl_tex.config(text=os.path.basename(path))

    def do_import(self):
        obj_path = getattr(self, "_pending_obj", None)
        if not obj_path:
            messagebox.showwarning("提示", "请先选择OBJ文件")
            return
        try:
            self.state["obj_path"] = obj_path
            self.state["obj_display_name"] = os.path.basename(obj_path)

            inx_path = getattr(self, "_pending_inx", None)
            self.state["doc"] = gc.load_doc(inx_path) if inx_path else gc.new_empty_doc()

            tex_path = getattr(self, "_pending_tex", None)
            if tex_path:
                with open(tex_path, "rb") as fh:
                    self.state["texture_bytes"] = fh.read()
            else:
                self.state["texture_bytes"] = None

            self.state["global_rotate"] = (0.0, 0.0, 0.0)
            for e in (self.e_grx, self.e_gry, self.e_grz):
                e.delete(0, tk.END); e.insert(0, "0")
            self.state["y_center"] = gc.compute_y_center(obj_path, 0.0, 0.0, 0.0)
            self.state["parts_cache_key"] = None
            self.reset_params()
            self._update_ycenter_label()
            self.refresh_deformers()
            self.lbl_status.config(text=f"已导入 {self.state['obj_display_name']}")
        except Exception as e:
            messagebox.showerror("导入失败", str(e))

    def apply_global_rotate(self):
        try:
            rx = float(self.e_grx.get() or 0)
            ry = float(self.e_gry.get() or 0)
            rz = float(self.e_grz.get() or 0)
        except ValueError:
            messagebox.showerror("错误", "旋转角度必须是数字")
            return
        self.state["global_rotate"] = (rx, ry, rz)
        self.state["y_center"] = gc.compute_y_center(self.state["obj_path"], rx, ry, rz)
        self.state["parts_cache_key"] = None
        self._update_ycenter_label()
        self.refresh_parts()

    def _update_ycenter_label(self):
        rx, ry, rz = self.state["global_rotate"]
        self.lbl_ycenter.config(text=f"X={rx}° Y={ry}° Z={rz}°  y_center_obj={self.state['y_center']:.4f}")

    def reset_params(self):
        for k, v in DEFAULTS.items():
            self.pv[k].set(v)
        self._on_cage_method_change()

    # ------------------------------------------------------------------
    # 参数面板联动
    # ------------------------------------------------------------------
    def _on_cage_method_change(self, event=None):
        cage_method = self.pv["cage_method"].get()
        if cage_method == "full-topology":
            self.pv["node_type"].set("meshgroup")
            self.cb_node.configure(values=["meshgroup"])
        else:
            self.cb_node.configure(values=["meshgroup", "part"])

        for w, show_for in ((self.f_cyl, "cylinder"), (self.f_ft, "full-topology"), (self.f_uv, "full-topology-uv")):
            if cage_method == show_for:
                w.grid()
            else:
                w.grid_remove()

        is_uv = cage_method == "full-topology-uv"
        roll_state = "disabled" if is_uv else "normal"
        self.e_roll_range.configure(state=roll_state)
        self.e_roll_bp.configure(state=roll_state)
        self.cb_roll_on.configure(state=roll_state)
        self.cb_roll_target.configure(state=("disabled" if is_uv else "readonly"))
        self.cb_roll_dir.configure(state=("disabled" if is_uv else "readonly"))
        if is_uv:
            self.var_roll_on.set(False)
            self.lbl_roll_note.config(text="full-topology-uv不支持roll，已自动关闭")
        else:
            self.lbl_roll_note.config(text="")

        cage_rot_state = "normal" if cage_method in ("cylinder", "full-topology") else "disabled"
        for child in self.f_cage_rot.winfo_children():
            try:
                child.configure(state=cage_rot_state)
            except tk.TclError:
                pass

        self.state["parts_cache_key"] = None
        self.refresh_parts()

    # ------------------------------------------------------------------
    # 部件列表
    # ------------------------------------------------------------------
    def refresh_parts(self):
        if not self.state["obj_path"]:
            return
        cage_method = self.pv["cage_method"].get()
        group_by = self.pv["group_by"].get()
        cache_key = (cage_method, group_by)
        if self.state["parts_cache_key"] != cache_key:
            self.state["parts_cache"] = gc.list_parts(self.state["obj_path"], cage_method, group_by)
            self.state["parts_cache_key"] = cache_key
        parts = self.state["parts_cache"]

        self.lb_parts.delete(0, tk.END)
        self.lb_parts.insert(tk.END, "(整个OBJ，不拆分)")
        self._part_names = ["(整个OBJ，不拆分)"] + list(parts.keys())
        for name, p in parts.items():
            self.lb_parts.insert(tk.END, f"{name}  (v={len(p['verts'])} f={len(p['faces'])})")
        self.lb_parts.selection_set(0)
        self._on_part_select()

    def _on_part_select(self, event=None):
        sel = self.lb_parts.curselection()
        idx = sel[0] if sel else 0
        name = self._part_names[idx] if idx < len(self._part_names) else "(整个OBJ，不拆分)"
        cage_method = self.pv["cage_method"].get()
        group_by = self.pv["group_by"].get()
        if name == "(整个OBJ，不拆分)":
            whole = gc.whole_model(self.state["obj_path"], cage_method, group_by)
            self.state["cur_verts"] = whole["verts"]
            self.state["cur_faces"] = whole["faces"]
            self.state["cur_uvs"] = whole["uvs"]
            default_name = self.state["obj_display_name"].rsplit(".", 1)[0]
        else:
            p = self.state["parts_cache"][name]
            self.state["cur_verts"] = p["verts"]
            self.state["cur_faces"] = p["faces"]
            self.state["cur_uvs"] = p["uvs"]
            default_name = name
        self.e_name.delete(0, tk.END)
        self.e_name.insert(0, default_name)
        uv_txt = "有UV" if self.state["cur_uvs"] is not None else "无UV"
        self.lbl_part_info.config(
            text=f"顶点数: {len(self.state['cur_verts'])}  三角面数: {len(self.state['cur_faces'])}  ({uv_txt})")
        self.txt_diag.delete("1.0", tk.END)

    def do_diagnose(self):
        if self.state["cur_uvs"] is None:
            messagebox.showinfo("提示", "这个部件没有UV数据，无法做island诊断")
            return
        diag = gc.diagnose_fragments(self.state["cur_verts"], self.state["cur_faces"], self.state["cur_uvs"])
        self.txt_diag.delete("1.0", tk.END)
        self.txt_diag.insert(tk.END, f"拆出 {diag['island_count']} 个UV连通island：\n")
        for isl in diag["islands"][:10]:
            self.txt_diag.insert(
                tk.END,
                f" 面={isl['face_count']} 顶点={isl['vert_count']} "
                f"中心={[round(x, 2) for x in isl['center_3d']]} "
                f"y范围={[round(y, 2) for y in isl['y_range']]}\n")
        if diag["island_count"] > 1:
            self.txt_diag.insert(
                tk.END,
                "\n>1块连通区域——如果它们3D位置分散在模型不同处，说明是碎片拼凑，"
                "建议换更细的分组方式，或者在Blender里把这几块拆成独立物体。\n")

    # ------------------------------------------------------------------
    # 已有deformer
    # ------------------------------------------------------------------
    def refresh_deformers(self):
        doc = self.state["doc"]
        if doc is None:
            return
        turn_params, roll_params = gc.list_existing_params(doc)
        self.state["turn_params"] = turn_params
        self.state["roll_params"] = roll_params

        self.lb_turn.delete(0, tk.END)
        for p in turn_params:
            n = len(set(b["node"] for b in p["bindings"]))
            self.lb_turn.insert(tk.END, f"{p['name']}  ({n}节点)")
        self.lb_roll.delete(0, tk.END)
        for p in roll_params:
            n = len(set(b["node"] for b in p["bindings"]))
            self.lb_roll.insert(tk.END, f"{p['name']}  ({n}节点)")

        node_names = gc.list_node_names(doc)
        self.lb_nodes.delete(0, tk.END)
        for n in node_names:
            self.lb_nodes.insert(tk.END, n)

        parent_values = ["(Root)"] + node_names
        self.cb_parent.configure(values=parent_values)
        if self.cb_parent.get() not in parent_values:
            self.cb_parent.set("(Root)")

        turn_values = ["(新建)"] + [p["name"] for p in turn_params]
        self.cb_turn_target.configure(values=turn_values)
        if self.cb_turn_target.get() not in turn_values:
            self.cb_turn_target.set("(新建)")

        roll_values = ["(新建)"] + [p["name"] for p in roll_params]
        self.cb_roll_target.configure(values=roll_values)
        if self.cb_roll_target.get() not in roll_values:
            self.cb_roll_target.set("(新建)")

    def _set_cage_rot_y(self, val):
        self.e_cage_ry.delete(0, tk.END)
        self.e_cage_ry.insert(0, str(val))

    # ------------------------------------------------------------------
    # 写入
    # ------------------------------------------------------------------
    def _fnum(self, entry, default=0.0):
        s = (entry.get() or "").strip()
        return float(s) if s else default

    def _fopt(self, key):
        """左栏"空=自动"字段：返回None或float。"""
        s = self.pv[key].get().strip()
        return float(s) if s else None

    def do_write(self):
        if self.state["obj_path"] is None:
            messagebox.showwarning("提示", "请先导入OBJ")
            return
        try:
            cage_method = self.pv["cage_method"].get()
            node_type = self.pv["node_type"].get()
            name = self.e_name.get().strip()
            if not name:
                messagebox.showwarning("提示", "节点/参数名不能为空")
                return
            parent_choice = self.cb_parent.get()
            parent_name = None if parent_choice == "(Root)" else parent_choice

            verts = self.state["cur_verts"]
            rx, ry, rz = self.state["global_rotate"]
            if rx or ry or rz:
                verts = rotate_verts_deg(verts, rx, ry, rz)

            turn_target_param = None
            if self.var_turn_on.get() and self.cb_turn_target.get() != "(新建)":
                turn_target_param = next(
                    p for p in self.state["turn_params"] if p["name"] == self.cb_turn_target.get())
            roll_target_param = None
            if self.var_roll_on.get() and self.cb_roll_target.get() != "(新建)":
                roll_target_param = next(
                    p for p in self.state["roll_params"] if p["name"] == self.cb_roll_target.get())

            rows_opt = self._fopt("rows")
            ray_radius_opt = self._fopt("ray_radius")
            texel_density_opt = self._fopt("texel_density")

            kwargs = dict(
                obj_verts=verts, obj_faces=self.state["cur_faces"], obj_uvs=self.state["cur_uvs"],
                name=name, parent_name=parent_name,
                y_center_obj=self.state["y_center"],
                cage_method=cage_method, node_type=node_type,
                scale=float(self.pv["scale"].get() or 3000.0),
                cols=int(float(self.pv["cols"].get() or 26)),
                rows=(int(rows_opt) if rows_opt is not None else None),
                expand_frac=float(self.pv["expand_frac"].get() or 0.15),
                ray_radius=ray_radius_opt,
                radius_margin=float(self.pv["radius_margin"].get() or 1.3),
                facing=self.pv["facing"].get(),
                z_threshold=float(self.pv["z_threshold"].get() or -0.04),
                cage_rotate_x=self._fnum(self.e_cage_rx, 0.0),
                cage_rotate_y=self._fnum(self.e_cage_ry, 0.0),
                cage_rotate_z=self._fnum(self.e_cage_rz, 0.0),
                texture_bytes=self.state["texture_bytes"],
                texel_density=texel_density_opt,
                create_turn=self.var_turn_on.get(), turn_target_param=turn_target_param,
                yaw_range=float(self.pv["yaw_range"].get() or 40.0),
                pitch_range=float(self.pv["pitch_range"].get() or 25.0),
                yaw_bp=int(float(self.pv["yaw_bp"].get() or 9)),
                pitch_bp=int(float(self.pv["pitch_bp"].get() or 5)),
                yaw_dir=self.cb_yaw_dir.get(), pitch_dir=self.cb_pitch_dir.get(),
                create_roll=self.var_roll_on.get(), roll_target_param=roll_target_param,
                roll_range=float(self.pv["roll_range"].get() or 15.0),
                roll_bp=int(float(self.pv["roll_bp"].get() or 5)),
                roll_dir=self.cb_roll_dir.get(),
            )
            result = gc.process_part(self.state["doc"], **kwargs)
            msg = f"已写入「{result.node_name}」，笼子顶点数={result.vert_count}"
            if result.texel_density_used:
                msg += f"，texel_density={result.texel_density_used:.1f}"
            if result.roll_skipped_reason:
                msg += " | " + result.roll_skipped_reason
            self.lbl_status.config(text=msg)
            self.refresh_deformers()
        except Exception as e:
            messagebox.showerror("写入失败", str(e))

    # ------------------------------------------------------------------
    # 导出
    # ------------------------------------------------------------------
    def browse_save_as(self):
        path = filedialog.asksaveasfilename(
            title="另存为", defaultextension=".inx",
            filetypes=[("Inochi2D files", "*.inx"), ("All files", "*.*")])
        if path:
            self.e_save_path.delete(0, tk.END)
            self.e_save_path.insert(0, path)

    def do_save(self):
        path = self.e_save_path.get().strip()
        if not path:
            messagebox.showwarning("提示", "请先指定保存路径")
            return
        if self.state["doc"] is None:
            messagebox.showwarning("提示", "还没有可保存的内容，请先导入OBJ")
            return
        try:
            gc.write_inx(path, self.state["doc"])
            self.lbl_save_status.config(text=f"已保存到 {path}", foreground="#0a6")
        except Exception as e:
            self.lbl_save_status.config(text=f"保存失败：{e}", foreground="#c33")


def main():
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
