# -*- coding: utf-8 -*-
"""占位stub：仅为满足node_builder.py/obj_pipeline.py的import依赖，主流程
(add_obj_deformer.py)不会用到这里的alpha建网格实现，属于旧版pipeline的残留依赖。"""
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class GeneratedMesh:
    verts: List[float]
    uvs: List[float]
    indices: List[int]
    origin: Tuple[float, float]
    bbox: Tuple[int, int, int, int]


def generate_mesh_from_alpha(rgba, point_spacing: float = 40.0) -> GeneratedMesh:
    raise NotImplementedError("mesh_gen.py是占位stub，没有实现真实的alpha建网格逻辑")
