# -*- coding: utf-8 -*-
"""
node_builder.py
-----------------
把图层配置(每层：图片+锚点标签+参数参与情况)按锚点的 group_path 自动归组，
生成Inochi2D的节点树(嵌套Node分组 + Part叶子节点)，并把每个图层的PNG编码
成纹理准备写入TEX_SECT。

节点schema已跟真实Inochi Creator导出的.inx样例核对过，字段和默认值都照抄。
"""

from __future__ import annotations
import io
import random
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import numpy as np
from PIL import Image

from anchors import AnchorDef, get_anchor
from mesh_gen import generate_mesh_from_alpha, GeneratedMesh
from inx_container import TextureEntry

_used_uuids: set = set()


def new_uuid() -> int:
    while True:
        u = random.randint(1, 2**32 - 2)
        if u not in _used_uuids:
            _used_uuids.add(u)
            return u


def register_existing_uuids(uuids):
    _used_uuids.update(uuids)


@dataclass
class LayerSpec:
    id: str
    image_path: str
    draw_order: float           # 数值越大越靠"前"(具体前后方向如渲染出来反了，改成取负号)
    anchor: str                 # 锚点标签，见 anchors.py
    depth_override: Optional[float] = None
    params: List[str] = field(default_factory=list)   # 例如 ["yaw_pitch","roll"]
    mirror_of: Optional[str] = None  # 若这一层是另一层的镜像自动生成的，记录来源layer id
    point_spacing: float = 40.0      # 网格密度，deform图层建议调小(更密)
    psd_layer_path: str = ""
    depth_bias: float = 0.0          # 3D投影模式下，手动叠加的深度修正量(像素单位)，默认0=纯公式
    uniform_depth: bool = False      # True=整层当成跟脸平行的统一深度平面(用图层中心点算一个深度广播给所有顶点)，
                                      # 不再让每个顶点各自采样轮廓曲线——适合眼睛这类小图层，避免被
                                      # 附近变化剧烈的区域(比如鼻梁)带偏产生不该有的形变
    parent_id: Optional[str] = None  # 若指定，这个图层的Part节点会直接嵌套进同一批layer_specs里
                                      # 那个id对应的Part节点内部(不经过anchor.group_path的虚拟分组)，
                                      # 匹配"脸部图层内部嵌套眼睛/鼻子/头发子图层"这类父子级结构
    absolute_depth: Optional[float] = None  # 不为None时完全跳过轮廓曲线公式，整层直接用这个绝对深度值
                                      # (还会再加depth_bias)——用于图层中心点位置本身在曲线上取值就
                                      # 不合理的情况(比如眼睛正好卡在鼻子隆起的高度上)
    dome: bool = False               # True=用椭球面公式算深度(不可分离，同一高度两侧会自然凹进去)，
                                      # 专门给"头部母版"这一层用，避免曲线×衰减那种可分离公式导致的
                                      # 横向整片跟着凸出的问题


@dataclass
class BuiltLayer:
    spec: LayerSpec
    node_uuid: int
    mesh: GeneratedMesh
    texture_index: int
    depth: float  # 最终生效的深度(override或锚点默认)
    rest_trans: Tuple[float, float, float]  # 写入transform.trans的静止位置
    world_offset: Tuple[float, float] = (0.0, 0.0)  # 被烘焙进mesh顶点的世界偏移量(测试用)


def _encode_png(rgba: np.ndarray) -> bytes:
    img = Image.fromarray(rgba, mode="RGBA")
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    return buf.getvalue()


def _make_group_node(name: str, uuid: int, children: list) -> dict:
    return {
        "uuid": uuid,
        "name": name,
        "type": "Node",
        "enabled": True,
        "zsort": 0.0,
        "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False,
        "children": children,
    }


def _make_part_node(spec: LayerSpec, uuid: int, mesh: GeneratedMesh, texture_index: int,
                     canvas_size: Tuple[int, int]) -> dict:
    # 图像像素坐标(左上角原点，Y向下) -> 画布中心为原点、Y向上 的世界坐标
    cw, ch = canvas_size
    ox_px, oy_px = mesh.origin
    world_x = ox_px - cw / 2.0
    # 局部Y方向不翻转(见mesh_gen.py)，world_y要用原始oy_px直接减去画布半高，
    # 不能加负号——否则跟local_y相加时无法正确抵消，会残留一个错误的偏移量。
    world_y = oy_px - ch / 2.0

    return {
        "uuid": uuid,
        "name": spec.id,
        "type": "Part",
        "enabled": True,
        "zsort": float(spec.draw_order),
        "transform": {"trans": [world_x, world_y, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False,
        "children": [],
        "mesh": {"verts": mesh.verts, "uvs": mesh.uvs, "indices": mesh.indices, "origin": [0.0, 0.0]},
        # 固定3个纹理槽位：albedo/emissive/bump，未使用的槽位用0xFFFFFFFF(uint32最大值)占位，
        # 必须给满3个元素，少了会导致Inochi Creator读取时越界崩溃。
        "textures": [texture_index, 4294967295, 4294967295],
        "blend_mode": "Normal",
        "tint": [1.0, 1.0, 1.0],
        "screenTint": [0.0, 0.0, 0.0],
        "emissionStrength": 1.0,
        "mask_threshold": 0.5,
        "opacity": 1.0,
        "psdLayerPath": spec.psd_layer_path,
    }, (world_x, world_y, 0.0), (0.0, 0.0)


def build_node_tree(layer_specs: List[LayerSpec], canvas_size: Tuple[int, int],
                     existing_uuids: Optional[set] = None):
    """
    返回: (root_node_dict, built_layers: Dict[layer_id, BuiltLayer], textures: List[TextureEntry],
           group_uuid_by_path: Dict[Tuple[str,...], int])

    支持两种归组方式：
    - spec.parent_id 指定时：这个图层的Part节点直接嵌套进同一批layer_specs里
      那个id对应的Part节点内部(真实层级嵌套，transform.trans改成相对父级的偏移量)。
    - 否则：走anchor.group_path的旧逻辑(虚拟Node分组，transform.trans是绝对画布坐标)。

    注意：BuiltLayer.rest_trans 无论哪种归组方式，存的都是"绝对画布坐标"下的值，
    供后续3D投影相关的数学计算用——那套计算全程假设统一的世界坐标系，不关心
    JSON里实际写的transform.trans是不是父级相对的。
    """
    if existing_uuids:
        register_existing_uuids(existing_uuids)

    textures: List[TextureEntry] = []
    built_layers: Dict[str, BuiltLayer] = {}
    part_dict_by_id: Dict[str, dict] = {}
    group_registry: Dict[Tuple[str, ...], dict] = {}

    def get_or_create_group(path: Tuple[str, ...]) -> dict:
        if path in group_registry:
            return group_registry[path]
        entry = {"uuid": new_uuid(), "name": path[-1], "part_nodes": [], "child_group_paths": []}
        group_registry[path] = entry
        if len(path) > 1:
            parent = get_or_create_group(path[:-1])
            if path not in parent["child_group_paths"]:
                parent["child_group_paths"].append(path)
        return entry

    for spec in layer_specs:
        img = Image.open(spec.image_path).convert("RGBA")
        rgba = np.array(img)
        mesh = generate_mesh_from_alpha(rgba, point_spacing=spec.point_spacing)

        # 裁剪贴图到内容包围盒(mesh.bbox)——这样贴图自己的几何中心正好等于
        # mesh顶点局部坐标用的原点(ox,oy)，Edit Mesh模式下贴图和mesh才能对齐；
        # 目前UV在mesh_gen.py里还是"相对整张画布"算的(px/w, py/h)，裁剪后贴图
        # 变小了，所以这里要把UV改成"相对裁剪框"，不然采样位置会不对。
        x0, y0, x1, y1 = mesh.bbox
        cropped_rgba = rgba[y0:y1, x0:x1]
        crop_w = max(x1 - x0, 1)
        crop_h = max(y1 - y0, 1)
        full_w, full_h = rgba.shape[1], rgba.shape[0]
        cropped_uvs = list(mesh.uvs)
        for i in range(0, len(cropped_uvs), 2):
            u_full = cropped_uvs[i]
            v_full = cropped_uvs[i + 1]
            px_ = u_full * full_w
            py_ = v_full * full_h
            cropped_uvs[i] = (px_ - x0) / crop_w
            cropped_uvs[i + 1] = (py_ - y0) / crop_h
        mesh.uvs = cropped_uvs

        png_bytes = _encode_png(cropped_rgba)
        tex_index = len(textures)
        textures.append(TextureEntry(data=png_bytes, encoding=0))

        node_uuid = new_uuid()
        part_dict, rest_trans, world_offset = _make_part_node(spec, node_uuid, mesh, tex_index, canvas_size)
        part_dict_by_id[spec.id] = part_dict

        anchor = get_anchor(spec.anchor)
        depth = spec.depth_override if spec.depth_override is not None else anchor.depth
        built_layers[spec.id] = BuiltLayer(
            spec=spec, node_uuid=node_uuid, mesh=mesh,
            texture_index=tex_index, depth=depth, rest_trans=rest_trans,
            world_offset=world_offset,
        )

    # 第二遍：按parent_id或anchor.group_path把每个part_dict挂到该去的地方
    for spec in layer_specs:
        part_dict = part_dict_by_id[spec.id]
        if spec.parent_id is not None:
            if spec.parent_id not in part_dict_by_id:
                raise KeyError(f"图层'{spec.id}'的parent_id='{spec.parent_id}'在layer_specs里找不到")
            parent_part = part_dict_by_id[spec.parent_id]
            parent_bl = built_layers[spec.parent_id]
            own_bl = built_layers[spec.id]
            # transform.trans改成相对父级的偏移量(父级也可能是被嵌套的，但父级自己的
            # rest_trans已经是绝对坐标，直接相减即可，层级越深不影响这一步的正确性)
            rel_x = own_bl.rest_trans[0] - parent_bl.rest_trans[0]
            rel_y = own_bl.rest_trans[1] - parent_bl.rest_trans[1]
            rel_z = own_bl.rest_trans[2] - parent_bl.rest_trans[2]
            part_dict["transform"]["trans"] = [rel_x, rel_y, rel_z]
            parent_part["children"].append(part_dict)
        else:
            anchor = get_anchor(spec.anchor)
            get_or_create_group(anchor.group_path)
            group_registry[anchor.group_path]["part_nodes"].append(part_dict)

    # 递归组装成嵌套的Node字典(只处理走anchor.group_path这条路的顶层图层；
    # parent_id嵌套的图层已经在上面直接塞进父级part_dict["children"]了)
    def assemble(path: Tuple[str, ...]) -> dict:
        entry = group_registry[path]
        children = list(entry["part_nodes"])
        for child_path in entry["child_group_paths"]:
            children.append(assemble(child_path))
        return _make_group_node(entry["name"], entry["uuid"], children)

    top_level_paths = [p for p in group_registry if len(p) == 1]
    root_children = [assemble(p) for p in top_level_paths]

    root = {
        "uuid": new_uuid(),
        "name": "Root",
        "type": "Node",
        "enabled": True,
        "zsort": 0.0,
        "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False,
        "children": root_children,
    }

    group_uuid_by_path = {p: e["uuid"] for p, e in group_registry.items()}
    return root, built_layers, textures, group_uuid_by_path
