# -*- coding: utf-8 -*-
"""
obj_head_model.py
--------------------
用真实3D头部OBJ模型代替纯数学公式估算深度：不再用"曲线×衰减"或"椭球面"去猜
深度，而是在头部范围内打一个规则网格，每个网格点往+Z方向(正脸朝向)发一条
射线，找模型表面最靠前的交点，拿到这个点真实的(x,y,z)3D坐标。旋转时对这些
真实3D坐标做旋转+正交投影，不再是估算。

OBJ坐标系约定：
- X: 左右(左负右正)
- Y: 上下(0=脖子根部, 最大值≈头顶)
- Z: 前后(正值=脸朝向的前方，鼻子在Z最大处；负值=后脑勺)
"""

from __future__ import annotations
import math
import numpy as np
from collections import OrderedDict
from dataclasses import dataclass
from typing import List, Tuple, Optional, Dict


def _parse_obj_raw(path: str, group_by: str = "object"):
    """解析OBJ原始数据(共享底层，load_obj/load_obj_parts/load_obj_parts_uv都基于这个)。
    返回(全局顶点列表, 全局UV列表, 分组字典)。group_by控制分组key怎么取：
    - "object"(默认)：按o/g标记(Blender物体名)
    - "material"：按usemtl标记(材质名)——同一个材质名可能横跨好几个不同的o物体
      (比如同一件衣服材质，衣服本体和鞋子都用它)，这种情况会被合并成一组
    - "object_material"：同时按"物体名::材质名"分组——最精细，能精确抠出"某个物体
      里属于某种材质的那部分"，不会像单纯material模式那样把不同物体但同材质的
      东西混在一起(比如能把"Body物体里的衣服材质部分"和"shirt物体的衣服材质"分开)

    分组字典的key是按标记出现顺序排列的名字，value是该组的三角面列表，每个三角面是
    3个(v_idx, vt_idx)角点组成的列表(四边形/多边形已扇形三角化)。vt_idx在face没写
    UV时是None。同一个key如果对应文件里的多个不连续段(比如Blender给同一物体的
    "本体材质"和"描边材质"各导出一个同名o块)，面会自动累加合并，不会覆盖丢失。
    """
    verts: List[List[float]] = []
    vts: List[List[float]] = []
    groups: "OrderedDict[str, list]" = OrderedDict()
    current_o = "(ungrouped)"
    current_mtl = "(no material)"

    def _current_key() -> str:
        if group_by == "object":
            return current_o
        if group_by == "material":
            return current_mtl
        return f"{current_o}::{current_mtl}"

    with open(path) as f:
        for line in f:
            if line.startswith('v '):
                p = line.split()
                verts.append([float(p[1]), float(p[2]), float(p[3])])
            elif line.startswith('vt '):
                p = line.split()
                vts.append([float(p[1]), float(p[2])])
            elif line.startswith('o ') or line.startswith('g '):
                name = line[2:].strip()
                if name:
                    current_o = name
            elif line.startswith('usemtl '):
                name = line[7:].strip()
                if name:
                    current_mtl = name
            elif line.startswith('f '):
                p = line.split()[1:]
                corners = []
                for tok in p:
                    seg = tok.split('/')
                    v_idx = int(seg[0]) - 1
                    vt_idx = int(seg[1]) - 1 if len(seg) > 1 and seg[1] != '' else None
                    corners.append((v_idx, vt_idx))
                tris = [[corners[0], corners[i], corners[i + 1]] for i in range(1, len(corners) - 1)]
                groups.setdefault(_current_key(), []).extend(tris)
    return verts, vts, groups


def load_obj(path: str) -> Tuple[np.ndarray, np.ndarray]:
    """返回(顶点数组Nx3, 三角面数组Mx3(0-based顶点索引))，四边形面会自动三角化(fan)。
    不区分o/g分组，把整个文件当一个模型读(向后兼容，行为跟之前完全一样)。"""
    verts, vts, groups = _parse_obj_raw(path)
    faces = [[c[0] for c in tri] for g in groups.values() for tri in g]
    return np.array(verts), np.array(faces, dtype=np.int64)


def _dedupe_by_position(verts_arr: np.ndarray, tris: list) -> Tuple[np.ndarray, np.ndarray]:
    """把一组三角面(角点是(v_idx,vt_idx)元组)按v_idx(位置)去重、局部重新编号，
    忽略vt——load_obj_parts用这个(不需要UV时的默认行为)。"""
    v_tris = [[c[0] for c in tri] for tri in tris]
    tris_arr = np.array(v_tris, dtype=np.int64)
    used = np.unique(tris_arr.reshape(-1))
    remap: Dict[int, int] = {int(g): i for i, g in enumerate(used)}
    local_faces = np.array(
        [[remap[int(a)], remap[int(b)], remap[int(c)]] for a, b, c in tris_arr],
        dtype=np.int64,
    )
    local_verts = verts_arr[used]
    return local_verts, local_faces


def load_obj_parts(path: str, group_by: str = "object") -> "OrderedDict[str, Tuple[np.ndarray, np.ndarray]]":
    """按o/g分组(group_by="object"，默认)或usemtl材质分组(group_by="material")解析OBJ，
    每个部件返回局部重新编号的(顶点Nx3, 三角面Mx3)。

    - 保持部件在文件里首次出现的顺序
    - 同名的多个o/g块或usemtl段自动合并成一个部件
    - 每个部件只保留自己的面实际引用到的顶点，重新从0编号(不是拿全局顶点表切片)
    - 整个文件都没有对应标记时，返回一个"(ungrouped)"/"(no material)"的部件，等价于整个模型

    返回的dict保持顺序，可以直接当"检测到的部件列表"展示给用户选。
    """
    verts, vts, groups = _parse_obj_raw(path, group_by=group_by)
    verts_arr = np.array(verts)
    result: "OrderedDict[str, Tuple[np.ndarray, np.ndarray]]" = OrderedDict()
    for name, tris in groups.items():
        if not tris:
            continue
        result[name] = _dedupe_by_position(verts_arr, tris)
    return result


def load_obj_parts_uv(path: str, group_by: str = "object") -> "OrderedDict[str, Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]]":
    """按o/g分组(默认)或usemtl材质分组解析OBJ，每个部件返回(顶点Nx3, 三角面Mx3, uvs Nx2或None)。

    跟load_obj_parts的区别：这个版本按(v_idx, vt_idx)组合去重，不是只按v_idx——
    同一个3D位置如果在UV上被切开成多份(贴图接缝很常见)，会展开成多个独立顶点
    (3D位置相同、UV不同)，这是处理UV接缝的标准方式，保证每个顶点只有一份UV。
    真实3D坐标(用来算deform)不受影响，共享同一个v_idx的顶点位置依然完全一致。

    某个部件的面里只要有任何一个角点没写vt(比如OBJ根本没有UV数据)，这个部件的
    uvs就返回None，此时verts/faces退化成跟load_obj_parts一样的按位置去重结果。
    """
    verts, vts, groups = _parse_obj_raw(path, group_by=group_by)
    verts_arr = np.array(verts)
    vts_arr = np.array(vts) if vts else None
    result: "OrderedDict[str, Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]]" = OrderedDict()
    for name, tris in groups.items():
        if not tris:
            continue
        has_uv = vts_arr is not None and all(c[1] is not None for tri in tris for c in tri)
        if not has_uv:
            local_verts, local_faces = _dedupe_by_position(verts_arr, tris)
            result[name] = (local_verts, local_faces, None)
            continue
        corner_to_local: Dict[Tuple[int, int], int] = {}
        local_verts_list: List[np.ndarray] = []
        local_uvs_list: List[np.ndarray] = []
        local_faces: List[List[int]] = []
        for tri in tris:
            face_idx = []
            for (v_idx, vt_idx) in tri:
                key = (v_idx, vt_idx)
                if key not in corner_to_local:
                    corner_to_local[key] = len(local_verts_list)
                    local_verts_list.append(verts_arr[v_idx])
                    local_uvs_list.append(vts_arr[vt_idx])
                face_idx.append(corner_to_local[key])
            local_faces.append(face_idx)
        result[name] = (
            np.array(local_verts_list),
            np.array(local_faces, dtype=np.int64),
            np.array(local_uvs_list),
        )
    return result


def load_obj_uv(path: str, group_by: str = "object") -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """跟load_obj一样不区分部件，返回整个模型的(verts, faces, uvs)——uvs在OBJ没有
    UV数据时是None。内部按分组各自展开UV接缝再拼回一个整体(顶点编号统一偏移)。"""
    parts = load_obj_parts_uv(path, group_by=group_by)
    if not parts:
        return np.zeros((0, 3)), np.zeros((0, 3), dtype=np.int64), None
    has_uv = all(uv is not None for _, _, uv in parts.values())
    all_v, all_f, all_uv = [], [], []
    offset = 0
    for pv, pf, puv in parts.values():
        all_v.append(pv)
        all_f.append(pf + offset)
        if has_uv:
            all_uv.append(puv)
        offset += len(pv)
    verts = np.concatenate(all_v, axis=0)
    faces = np.concatenate(all_f, axis=0)
    uvs = np.concatenate(all_uv, axis=0) if has_uv else None
    return verts, faces, uvs


def split_uv_islands(verts: np.ndarray, faces: np.ndarray, uvs: np.ndarray, min_faces: int = 1
                      ) -> List[Tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """把一份(verts,faces,uvs)按UV连通性拆成多个独立UV island(贴图上互不相连的区域)。

    要求verts/faces/uvs是load_obj_parts_uv()/load_obj_uv()那种已经按(v_idx,vt_idx)
    展开过UV接缝的数据——同一个3D位置如果在UV上被贴图接缝切开，会拆成不同的局部顶点。
    这样"两个三角面在UV空间里是否连通"就等价于"两个三角面在这份局部顶点索引下是否
    共享顶点"(标准的mesh连通分量问题)，不需要额外比较UV坐标数值是否相等——用
    Union-Find在面之间做连通分量分析即可。

    典型用途：一个OBJ物体(o标记)如果混了好几种材质/好几块贴图区域(比如同一个
    Blender物体里同时有皮肤和被遮住的衣服网格)，用这个函数可以精确地把它们
    分离成各自独立、UV范围紧凑的island，不依赖材质命名是否规范。

    返回按面数从多到少排序的list[(local_verts, local_faces, local_uvs)]，面数少于
    min_faces的island会被丢弃(通常是杂讯三角形，默认min_faces=1不丢弃任何东西)。
    """
    n = len(verts)
    parent = list(range(n))

    def find(x: int) -> int:
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x

    def union(a: int, b: int) -> None:
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    for f in faces:
        union(int(f[0]), int(f[1]))
        union(int(f[1]), int(f[2]))

    groups: Dict[int, list] = {}
    for f in faces:
        root = find(int(f[0]))
        groups.setdefault(root, []).append(f)

    islands: List[Tuple[np.ndarray, np.ndarray, np.ndarray]] = []
    for flist in groups.values():
        if len(flist) < min_faces:
            continue
        used = sorted(set(int(x) for f in flist for x in f))
        remap = {v: i for i, v in enumerate(used)}
        local_faces = np.array(
            [[remap[int(a)], remap[int(b)], remap[int(c)]] for a, b, c in flist],
            dtype=np.int64,
        )
        islands.append((verts[used], local_faces, uvs[used]))

    islands.sort(key=lambda x: -len(x[1]))
    return islands


def load_obj_islands_uv(path: str, min_faces: int = 1
                         ) -> "OrderedDict[str, Tuple[np.ndarray, np.ndarray, np.ndarray]]":
    """把整个OBJ按UV连通性拆成独立island(见split_uv_islands)，不依赖o/g/usemtl标记，
    纯粹按贴图上是否相连判断——比--group-by material更精确(不依赖材质命名规范)，
    能拆出材质分组拆不出来的情况(比如同一个材质其实覆盖了好几块互不相邻的区域)。
    要求OBJ本身有UV数据，没有UV数据会报错(ValueError)。

    返回OrderedDict，key是"island_NNN"(按面数从多到少编号)，value是
    (局部顶点Nx3, 局部三角面Mx3, 局部UV Nx2)。
    """
    verts, faces, uvs = load_obj_uv(path, group_by="object")
    if uvs is None:
        raise ValueError(f"{path} 没有UV数据，无法按UV island拆分")
    islands = split_uv_islands(verts, faces, uvs, min_faces=min_faces)
    result: "OrderedDict[str, Tuple[np.ndarray, np.ndarray, np.ndarray]]" = OrderedDict()
    for i, (iv, ifac, iuv) in enumerate(islands):
        result[f"island_{i:03d}"] = (iv, ifac, iuv)
    return result


def _ray_mesh_intersect_frontmost(verts, faces, ray_origin, ray_dir):
    """单条射线跟所有三角形求交(Möller–Trumbore)，返回沿ray_dir方向最先碰到的交点，没交上返回None。"""
    v0 = verts[faces[:, 0]]
    v1 = verts[faces[:, 1]]
    v2 = verts[faces[:, 2]]
    e1 = v1 - v0
    e2 = v2 - v0
    h = np.cross(ray_dir, e2)
    a = np.einsum('ij,ij->i', e1, h)
    valid = np.abs(a) > 1e-9
    f = np.zeros_like(a)
    f[valid] = 1.0 / a[valid]
    s = ray_origin - v0
    u = f * np.einsum('ij,ij->i', s, h)
    valid &= (u >= -1e-6) & (u <= 1 + 1e-6)
    q = np.cross(s, e1)
    v = f * np.dot(q, ray_dir)
    valid &= (v >= -1e-6) & (u + v <= 1 + 1e-6)
    t = f * np.einsum('ij,ij->i', e2, q)
    valid &= t > 1e-6
    if not valid.any():
        return None
    ts = t[valid]
    return ray_origin + ray_dir * ts[np.argmin(ts)]


def build_head_grid_cylindrical(obj_verts: np.ndarray, obj_faces: np.ndarray,
                                 y_range: Tuple[float, float],
                                 cols: int, rows: int,
                                 ray_radius: float = 0.5) -> HeadGrid:
    """
    柱面展开投影：每一列代表绕Y轴转一圈的角度(0~2π)，每一行代表高度。
    角度定义：col_frac=0.5(正中间)对应正前方(+Z朝向观众)，col_frac=0或1
    对应正后方——这样"整张图裹在头上"时，正脸天然落在贴图中央，头两侧
    到后脑勺分别往贴图左右两边展开，边缘对接处正好在后脑勺(通常被头发挡住)。
    从半径ray_radius处朝轴心方向发射线，保证只要头部形状大致是"从中轴看
    是凸的"，每个网格点都能100%命中，不会有射线落空的情况。
    """
    ys = np.linspace(y_range[0], y_range[1], rows)
    grid_3d = np.zeros((rows, cols, 3))
    hit_mask = np.zeros((rows, cols), dtype=bool)
    for iy, y in enumerate(ys):
        for ix in range(cols):
            col_frac = ix / (cols - 1)
            angle = (col_frac - 0.5) * 2.0 * math.pi  # -π ~ +π，0.5对应角度0(正前方)
            sin_a, cos_a = math.sin(angle), math.cos(angle)
            origin = np.array([ray_radius * sin_a, y, ray_radius * cos_a])
            direction = np.array([-sin_a, 0.0, -cos_a])
            hit = _ray_mesh_intersect_frontmost(obj_verts, obj_faces, origin, direction)
            if hit is not None:
                grid_3d[iy, ix] = hit
                hit_mask[iy, ix] = True
            else:
                grid_3d[iy, ix] = origin + direction * ray_radius  # 兜底：落在半径处，避免留空洞
    return HeadGrid(grid_3d=grid_3d, hit_mask=hit_mask, rows=rows, cols=cols)



@dataclass
class HeadGrid:
    grid_3d: np.ndarray   # (rows, cols, 3) 每个网格点的真实3D坐标(OBJ单位)，miss的点z=0
    hit_mask: np.ndarray  # (rows, cols) bool，是否成功打到模型表面
    rows: int
    cols: int


def build_head_grid(obj_verts: np.ndarray, obj_faces: np.ndarray,
                     x_range: Tuple[float, float], y_range: Tuple[float, float],
                     cols: int, rows: int, ray_start_z: float = 0.5,
                     expand_frac: float = 0.0, from_back: bool = False) -> HeadGrid:
    """在指定的(x,y)范围内打一个cols×rows的规则网格，每个点往-Z方向发射线
    (起点在+Z远处)寻找模型表面最靠前的交点。没打中的点z填0(留在原地不额外凸出/凹陷)。
    expand_frac>0时，实际采样范围会在x_range/y_range基础上各自往外扩这么大比例
    (比如0.15代表左右各多扩15%的宽度)——给笼子(cage)用，比它要带动的内容范围
    更大，这样笼子边缘会有真实打到模型表面的采样点，不是从紧贴内容边缘的稀疏
    采样里勉强借几个格子。
    from_back=True时反过来，从-Z往+Z方向打(起点在模型后方)，取模型**背面**最靠后
    的表面深度——专门给后发这类实际贴在头后方的部件用，不然默认的正面射线会
    在这类区域打到额头/脸颊等正面表面，深度完全取错，光靠depth_bias修不回来。"""
    if expand_frac > 0:
        xw = (x_range[1] - x_range[0]) * expand_frac
        yw = (y_range[1] - y_range[0]) * expand_frac
        x_range = (x_range[0] - xw, x_range[1] + xw)
        y_range = (y_range[0] - yw, y_range[1] + yw)
    xs = np.linspace(x_range[0], x_range[1], cols)
    ys = np.linspace(y_range[0], y_range[1], rows)
    grid_3d = np.zeros((rows, cols, 3))
    hit_mask = np.zeros((rows, cols), dtype=bool)
    if from_back:
        direction = np.array([0.0, 0.0, 1.0])
        start_z = -ray_start_z
    else:
        direction = np.array([0.0, 0.0, -1.0])
        start_z = ray_start_z
    for iy, y in enumerate(ys):
        for ix, x in enumerate(xs):
            origin = np.array([x, y, start_z])
            hit = _ray_mesh_intersect_frontmost(obj_verts, obj_faces, origin, direction)
            if hit is not None:
                grid_3d[iy, ix] = hit
                hit_mask[iy, ix] = True
            else:
                grid_3d[iy, ix] = [x, y, 0.0]
    return HeadGrid(grid_3d=grid_3d, hit_mask=hit_mask, rows=rows, cols=cols)


def grid_to_mesh_data(grid: HeadGrid, scale: float, canvas_center_y_obj: float = 0.0,
                       trim_misses: bool = True, margin_rings: int = 1
                       ) -> Tuple[List[float], List[float], List[int], List[float]]:
    """
    把HeadGrid转成我们node_builder用的mesh格式：
    - verts_flat：静止姿势(不旋转，直接丢弃z)下的局部顶点坐标(像素单位)，obj_x*scale，
      obj_y要取负再乘scale(OBJ的Y向上为正，我们的约定Y向下为正，跟像素行方向一致)
    - uvs_flat：网格自身的归一化uv(0~1)
    - indices：网格三角化(每个cell拆两个三角形)
    - obj_3d_flat：每个顶点对应的真实OBJ 3D坐标(x,y,z)，供后续算不同角度的deform用

    trim_misses=True时，没有命中模型表面的网格点大部分会被剔除，但会保留命中
    区域外margin_rings圈的"缓冲区"(用它们自己的(x,y)、深度按最近命中点做简单
    延伸)，不是严格贴着命中边界硬裁剪——如果贴图内容(比如子级Part自己的mesh)
    刚好落在裁剪边界上或压线，会因为找不到所在的三角形而"留在原地不跟着形变"，
    看起来像被拉伸/撕裂。留一圈缓冲区能让实际内容离形变边界总有点余量。
    """
    rows, cols = grid.rows, grid.cols
    keep_mask = grid.hit_mask.copy()
    grid_3d = grid.grid_3d.copy()
    if trim_misses and margin_rings > 0:
        # 8个方向(上下左右+四个对角)，每个方向如果"紧邻的命中点"和"紧邻点再往
        # 同方向多一步的命中点"都存在，就用这两个点做线性外推(new = 2*near - far)，
        # 沿着边缘各自的走向往外延伸一格，不是整体朝一个中心缩放——不规则形状
        # (比如头发)的每条边走向都不一样，各自外推才能贴合真实轮廓。
        directions = [(-1, 0), (1, 0), (0, -1), (0, 1), (-1, -1), (-1, 1), (1, -1), (1, 1)]
        for _ in range(margin_rings):
            dilated = keep_mask.copy()
            dilated_3d = grid_3d.copy()
            for iy in range(rows):
                for ix in range(cols):
                    if keep_mask[iy, ix]:
                        continue
                    extrapolated = []
                    for dy, dx in directions:
                        ny, nx = iy + dy, ix + dx  # 紧邻的命中点(离缺口最近)
                        fy, fx = iy + 2 * dy, ix + 2 * dx  # 再往同方向多一步的点
                        if not (0 <= ny < rows and 0 <= nx < cols):
                            continue
                        if not (0 <= fy < rows and 0 <= fx < cols):
                            continue
                        if keep_mask[ny, nx] and keep_mask[fy, fx]:
                            near = grid_3d[ny, nx]
                            far = grid_3d[fy, fx]
                            extrapolated.append(2 * near - far)
                    if extrapolated:
                        dilated[iy, ix] = True
                        dilated_3d[iy, ix] = np.mean(extrapolated, axis=0)
            keep_mask = dilated
            grid_3d = dilated_3d
        # 补一遍简单的"借邻居z值"兜底，处理线性外推没能覆盖到的角落(比如整条边都
        # 只有1个命中点、凑不出两点线性外推的情况)，避免这些点完全没数据被漏掉
        for _ in range(margin_rings):
            dilated = keep_mask.copy()
            dilated_3d = grid_3d.copy()
            for iy in range(rows):
                for ix in range(cols):
                    if keep_mask[iy, ix]:
                        continue
                    y0, y1 = max(0, iy - 1), min(rows, iy + 2)
                    x0, x1 = max(0, ix - 1), min(cols, ix + 2)
                    neigh_mask = keep_mask[y0:y1, x0:x1]
                    if neigh_mask.any():
                        dilated[iy, ix] = True
                        neigh_3d = grid_3d[y0:y1, x0:x1].reshape(-1, 3)
                        neigh_flat_mask = neigh_mask.reshape(-1)
                        dilated_3d[iy, ix] = neigh_3d[neigh_flat_mask][0]
            keep_mask = dilated
            grid_3d = dilated_3d

    verts_flat: List[float] = []
    uvs_flat: List[float] = []
    obj_3d_flat: List[float] = []
    index_map = {}  # (iy,ix) -> 新顶点索引，只有保留下来的点才有
    for iy in range(rows):
        for ix in range(cols):
            if trim_misses and not keep_mask[iy, ix]:
                continue
            ox, oy, oz = grid_3d[iy, ix]
            lx = ox * scale
            ly = -(oy - canvas_center_y_obj) * scale
            index_map[(iy, ix)] = len(verts_flat) // 2
            verts_flat += [lx, ly]
            obj_3d_flat += [ox, oy, oz]
            uvs_flat += [ix / (cols - 1), iy / (rows - 1)]

    indices: List[int] = []
    for iy in range(rows - 1):
        for ix in range(cols - 1):
            keys = [(iy, ix), (iy, ix + 1), (iy + 1, ix), (iy + 1, ix + 1)]
            if trim_misses and not all(k in index_map for k in keys):
                continue  # 这个cell四个角有任意一个没保留，整个cell跳过不生成三角形
            i00 = index_map[(iy, ix)]
            i10 = index_map[(iy, ix + 1)]
            i01 = index_map[(iy + 1, ix)]
            i11 = index_map[(iy + 1, ix + 1)]
            indices += [i00, i10, i01]
            indices += [i10, i11, i01]

    return verts_flat, uvs_flat, indices, obj_3d_flat


def flat_grid_mesh_data(rows: int, cols: int, width_px: float, height_px: float
                         ) -> Tuple[List[float], List[float], List[int]]:
    """
    生成"摊平矩形"版本的静止mesh(верts)：网格点均匀铺满一个width_px×height_px的矩形，
    不参考任何3D投影——柱面展开(build_head_grid_cylindrical)时，正脸和后脑勺的点
    3D位置差异很大但直接丢Z会重叠，所以静止姿势不能再用"丢Z"，只能用这种纯粹按网格
    索引摆位置的矩形布局；每个角度断点(包括正脸朝向那个断点)都需要deform数据
    把这个矩形"包"成对应角度的真实形状。
    返回(verts_flat, uvs_flat, indices)。
    """
    verts_flat: List[float] = []
    uvs_flat: List[float] = []
    for iy in range(rows):
        for ix in range(cols):
            col_frac = ix / (cols - 1)
            row_frac = iy / (rows - 1)
            lx = (col_frac - 0.5) * width_px
            # iy=0对应y_range[0](OBJ Y值最小，脖子根部)，iy=rows-1对应y_range[1](头顶)。
            # 跟grid_to_mesh_data里"ly = -(oy - center) * scale"的约定保持一致——
            # OBJ Y越大(越靠头顶)，ly要越小(画面越靠上)，所以这里要取负号，
            # 不然头顶和脖子根部在画面上会整个上下颠倒。
            ly = -(row_frac - 0.5) * height_px
            verts_flat += [lx, ly]
            uvs_flat += [col_frac, row_frac]

    indices: List[int] = []
    for iy in range(rows - 1):
        for ix in range(cols - 1):
            i00 = iy * cols + ix
            i10 = iy * cols + ix + 1
            i01 = (iy + 1) * cols + ix
            i11 = (iy + 1) * cols + ix + 1
            indices += [i00, i10, i01]
            indices += [i10, i11, i01]
    return verts_flat, uvs_flat, indices


def cylindrical_grid_to_mesh_data(grid: "HeadGrid", width_px: float, height_px: float
                                   ) -> Tuple[List[float], List[float], List[int], List[float]]:
    """
    柱面展开网格(build_head_grid_cylindrical的结果)专用的mesh数据生成：
    静止姿势直接用flat_grid_mesh_data铺一个标准的width_px×height_px矩形(不裁剪、
    不按命中与否取舍，永远是完整的cols×rows规则网格，不会因为射线偶尔打空
    而缺角)，obj_3d_flat则原样保留每个格点真实的OBJ 3D坐标(与flat_grid_mesh_data
    同样的iy外层、ix内层顺序展开)，供后续yaw/pitch/roll旋转反推deform用——
    静止形状永远是矩形，真实3D坐标只负责"这个矩形转到某个角度时应该变成
    什么样"，两者互不影响。
    返回(verts_flat, uvs_flat, indices, obj_3d_flat)。
    """
    rows, cols = grid.rows, grid.cols
    verts_flat, uvs_flat, indices = flat_grid_mesh_data(rows, cols, width_px, height_px)
    obj_3d_flat: List[float] = []
    for iy in range(rows):
        for ix in range(cols):
            obj_3d_flat += grid.grid_3d[iy, ix].tolist()
    return verts_flat, uvs_flat, indices, obj_3d_flat


def compute_ray_radius(obj_verts: np.ndarray, y_range: Tuple[float, float],
                        radius_margin: float = 1.3) -> float:
    """
    自动估算柱面展开射线的起始半径：取obj在y_range范围内所有顶点到Y轴的
    水平距离(sqrt(x^2+z^2))的最大值，再乘一个安全系数(radius_margin)往外扩，
    保证射线起点必定在模型外侧，不会一开始就卡在模型内部导致打不中或打反。
    """
    mask = (obj_verts[:, 1] >= y_range[0]) & (obj_verts[:, 1] <= y_range[1])
    if not mask.any():
        mask = np.ones(len(obj_verts), dtype=bool)
    horiz = np.sqrt(obj_verts[mask, 0] ** 2 + obj_verts[mask, 2] ** 2)
    return float(horiz.max()) * radius_margin if len(horiz) else 0.5


def scale_cage(verts_flat: List[float], obj_xyz: np.ndarray, scale_factor: float = 1.03
               ) -> Tuple[List[float], np.ndarray]:
    """
    笼子(cage)最简单可靠的做法：直接复制内容mesh本身的顶点(拓扑完全一致，
    不用另外采样)，绕几何中心整体等比例放大一点点。这样内容mesh的每个点
    永远稳稳落在笼子内部(因为笼子就是把同一个形状放大了)，不会有独立射线
    采样导致的密度不均/数据不对应问题。obj_xyz(用于算deform的真实3D坐标)
    也同步在OBJ坐标系里绕自己的中心做同样比例的缩放，保持跟2D verts一致。
    """
    verts = np.array(verts_flat).reshape(-1, 2)
    center_2d = verts.mean(axis=0)
    cage_verts = center_2d + (verts - center_2d) * scale_factor
    cage_verts_flat = cage_verts.reshape(-1).tolist()

    center_3d = obj_xyz.mean(axis=0)
    cage_obj_xyz = center_3d + (obj_xyz - center_3d) * scale_factor
    return cage_verts_flat, cage_obj_xyz


def build_full_topology_cage(obj_verts: np.ndarray, obj_faces: np.ndarray,
                              scale: float, y_center_obj: float,
                              z_threshold: float = -0.04, depth_bias_obj: float = 0.0,
                              facing: str = "front"
                              ) -> Tuple[List[float], List[int], np.ndarray, bool]:
    """
    笼子(不渲染贴图)不需要像内容mesh那样局限在"正对镜头能看到的轮廓"内——
    之前逐列发射线的方法，天生只能覆盖单个方向的射线能打到的范围，轮廓外一点
    真实几何数据都拿不到，只能靠外推硬凑，这也是大角度转动时边缘顶点容易
    过度拉伸失真的根本原因。

    这个函数直接用OBJ模型自己的顶点+三角面拓扑当笼子，不再重新打网格采样——
    模型的三角面本来就自然延伸到头侧面(靠近侧脸的部分)，只按z过滤掉看不见影响的
    那一面顶点，笼子范围因此比逐列射线采样广得多，大角度时边缘也有真实几何数据
    支撑，不用靠外推硬撑。

    facing="front"(默认)：保留朝向+Z(正脸方向)的顶点，只砍掉z<=z_threshold的纯背面
    一小块(z_threshold越小，保留越多；默认-0.04只排除头正后方一小块)。
    facing="back"：反过来，保留z<-z_threshold的顶点(朝向-Z/后脑勺方向)，只砍掉纯
    正面一小块；同时静止姿势的2D展开(verts_flat)左右镜像——因为这对应的是"人站在
    模型背后往前看"这个作画视角，直接正交投影会是从前面透视看背面的镜像效果。
    注意：kept_verts_3d(真实3D坐标，后续算deform要用)**不镜像**，保持物理正确；
    调用方(build_yaw_pitch_param)需要对这个cage传mirror_x=True，才能让"镜像后的
    静止位置"和"根据未镜像真实3D坐标算出来的旋转后新位置"用同一套规则比较，
    不然算出来的deform方向会全错。

    返回(verts_flat像素单位2D坐标, indices三角化索引, obj_xyz真实3D坐标供算deform用,
    mirror_x这个cage是否镜像了2D展开——直接传给build_yaw_pitch_param用)。
    """
    if facing == "back":
        mask = obj_verts[:, 2] < -z_threshold
        mirror_x = True
    else:
        mask = obj_verts[:, 2] > z_threshold
        mirror_x = False

    keep_idx = np.where(mask)[0]
    index_map = {int(old): i for i, old in enumerate(keep_idx)}
    kept_verts_3d = obj_verts[mask].copy()
    kept_verts_3d[:, 2] += depth_bias_obj

    indices: List[int] = []
    for f in obj_faces:
        if mask[f[0]] and mask[f[1]] and mask[f[2]]:
            indices += [index_map[int(f[0])], index_map[int(f[1])], index_map[int(f[2])]]

    verts_flat: List[float] = []
    for ox, oy, oz in kept_verts_3d:
        lx = (-ox if mirror_x else ox) * scale
        ly = -(oy - y_center_obj) * scale
        verts_flat += [lx, ly]

    return verts_flat, indices, kept_verts_3d, mirror_x


def rotate_verts_deg(verts: np.ndarray, rot_x: float = 0.0, rot_y: float = 0.0,
                      rot_z: float = 0.0, inverse: bool = False) -> np.ndarray:
    """把verts(Nx3)绕原点(0,0,0)依次绕X、Y、Z轴转rot_x/rot_y/rot_z度(角度制，右手系)，
    返回旋转后的新数组，不修改原数组。用于修正OBJ建模时轴没对齐/想在处理前先换个朝向
    的场景——单纯对原始OBJ坐标做几何旋转，跟yaw/pitch/roll这些运行时的deform参数无关，
    这里转完之后的坐标才是后续所有笼子生成/y-range计算的基准。

    inverse=True时算的是**精确的逆旋转**(不是简单地把三个角度取反再按原顺序转一遍——
    3D旋转顺序不可交换，真正的逆需要按Z、Y、X反序、每个角度取反才能精确撤销)。用于
    "笼子朝向"这类需要"临时转过去建笼子，再转回来算真实3D旋转数学"的场景：比如
    hair_back，用rotate_verts_deg(v, rot_y=180)转过去建笼子(让柱面展开的"正中间"
    对应模型背面而不是正面)，笼子建完后再用rotate_verts_deg(cage_obj_xyz, rot_y=180,
    inverse=True)把笼子采样到的真实3D坐标转回原始朝向，这样算transform.t.x/t.y/deform
    时用的还是跟身体其它部位同一套坐标系，转头动画时才会跟着身体一起动，不会把这个
    部件的旋转动画基准也带偏成"新正面自己转"。
    """
    def _rot(v: np.ndarray, axis: str, deg: float) -> np.ndarray:
        if deg == 0.0:
            return v
        r = math.radians(deg)
        c, s = math.cos(r), math.sin(r)
        v = v.copy()
        if axis == 'x':
            y, z = v[:, 1].copy(), v[:, 2].copy()
            v[:, 1] = y * c - z * s
            v[:, 2] = y * s + z * c
        elif axis == 'y':
            x, z = v[:, 0].copy(), v[:, 2].copy()
            v[:, 0] = x * c + z * s
            v[:, 2] = -x * s + z * c
        elif axis == 'z':
            x, y = v[:, 0].copy(), v[:, 1].copy()
            v[:, 0] = x * c - y * s
            v[:, 1] = x * s + y * c
        return v

    out = verts.copy()
    if inverse:
        out = _rot(out, 'z', -rot_z)
        out = _rot(out, 'y', -rot_y)
        out = _rot(out, 'x', -rot_x)
    else:
        out = _rot(out, 'x', rot_x)
        out = _rot(out, 'y', rot_y)
        out = _rot(out, 'z', rot_z)
    return out


def build_full_topology_cage_uv(obj_verts: np.ndarray, obj_faces: np.ndarray, obj_uvs: np.ndarray,
                                 tex_width: Optional[float] = None, tex_height: Optional[float] = None,
                                 fallback_scale: float = 1000.0
                                 ) -> Tuple[List[float], List[int], np.ndarray]:
    """全拓扑复用+复用OBJ自带UV的方式：拓扑直接用模型自己的顶点/三角面(不重新采样)，
    真正的UV数据用在调用方的mesh.uvs字段上(见build_standalone_meshgroup_full_topology_uv
    的node_type="part"分支)。

    静止姿势的画面位置(verts_flat)公式是`(u-0.5)*贴图像素宽度`和`(0.5-v)*贴图像素高度`。
    U轴不翻转，V轴需要翻转：OBJ文件(比如Blender导出)的`vt`用标准OBJ约定(V=0在贴图底部)，
    而Inochi2D的Part顶点坐标约定是"贴图顶部对应更小/更靠上"，两者的V方向刚好相反，所以
    要用`0.5-v`而不是`v-0.5`才能让静止姿势的画面朝向正确。
    传了tex_width/tex_height(通常是**已经按这个部件的UV包围盒裁剪过的小贴图**的真实
    像素宽高，不是整张共享图集的尺寸——调用方add_obj_deformer.py会在传真实贴图路径时
    自动做这个裁剪+UV重新归一化，见那边的说明)就用这个；没有真实贴图就退化用
    fallback_scale。

    返回(verts_flat像素单位2D坐标, indices三角化索引, obj_xyz真实3D坐标供算deform用)。
    """
    w = tex_width if tex_width else fallback_scale
    h = tex_height if tex_height else fallback_scale
    verts_flat: List[float] = []
    for uu, vv in obj_uvs:
        px = (float(uu) - 0.5) * w
        py = (0.5 - float(vv)) * h
        verts_flat += [px, py]
    indices = obj_faces.reshape(-1).tolist()
    return verts_flat, indices, obj_verts.copy()


def rotate_project_real(obj_xyz: np.ndarray, yaw_rad: float, pitch_rad: float, roll_rad: float,
                         pivot: np.ndarray) -> np.ndarray:
    """对真实OBJ 3D坐标做旋转(绕pivot)+正交投影(丢弃z)，返回(N,2)的新(x,y)——注意这里
    直接在OBJ原始坐标系下算(Y向上为正)，跟grid_to_mesh_data的像素坐标系是两套坐标，
    调用方需要自己做同样的翻转(取负*scale)才能跟其他mesh顶点用同一个约定。"""
    p = obj_xyz - pivot
    x, y, z = p[:, 0], p[:, 1], p[:, 2]

    cy, sy = math.cos(yaw_rad), math.sin(yaw_rad)
    x1 = x * cy + z * sy
    z1 = -x * sy + z * cy
    y1 = y

    cp, sp = math.cos(pitch_rad), math.sin(pitch_rad)
    y2 = y1 * cp - z1 * sp
    z2 = y1 * sp + z1 * cp
    x2 = x1

    cr, sr = math.cos(roll_rad), math.sin(roll_rad)
    x3 = x2 * cr - y2 * sr
    y3 = x2 * sr + y2 * cr

    new_xy = np.stack([x3, y3], axis=-1) + pivot[:2]
    return new_xy
