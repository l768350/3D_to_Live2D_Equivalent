# -*- coding: utf-8 -*-
"""
app.py
-------
Inochi2D OBJ Deformer GUI(Streamlit)。

只负责界面和参数拼装，所有实际计算都调用gui_core.py(而gui_core.py又只是
add_obj_deformer.py等核心文件的薄封装，没有改动任何一行核心逻辑)。

运行方式：
    pip install streamlit numpy pillow --break-system-packages   # 首次
    streamlit run app.py
"""
import os
import tempfile

import streamlit as st

import gui_core as gc
from obj_head_model import rotate_verts_deg

st.set_page_config(page_title="Inochi2D OBJ Deformer", layout="wide")

WORKDIR = tempfile.mkdtemp(prefix="inochi2d_gui_")

DEFAULTS = {
    "cage_method": "cylinder",
    "node_type": "meshgroup",
    "group_by": "object",
    "scale": 3000.0,
    "cols": 26,
    "rows_override": False,
    "rows": 26,
    "expand_frac": 0.15,
    "ray_radius_override": False,
    "ray_radius": 1.0,
    "radius_margin": 1.3,
    "facing": "front",
    "z_threshold": -0.04,
    "texel_density_override": False,
    "texel_density": 1000.0,
    "yaw_range": 40.0,
    "pitch_range": 25.0,
    "roll_range": 15.0,
    "yaw_bp": 9,
    "pitch_bp": 5,
    "roll_bp": 5,
}


def reset_params():
    for k, v in DEFAULTS.items():
        st.session_state[f"p_{k}"] = v


def pget(key):
    """读取左栏参数（带默认值兜底，避免第一次渲染时KeyError）。"""
    return st.session_state.get(f"p_{key}", DEFAULTS[key])


# ---------------------------------------------------------------------------
# 顶部：导入
# ---------------------------------------------------------------------------
st.title("3D_to_Live2D_equivalent")

with st.container(border=True):
    c1, c2, c3, c4 = st.columns(4)
    with c1:
        obj_file = st.file_uploader("导入OBJ", type=["obj"])
    with c2:
        inx_file = st.file_uploader("读取已有inx(可选)", type=["inx", "inp"])
    with c3:
        texture_file = st.file_uploader("贴图(可选，共享图集PNG)", type=["png"])
    with c4:
        output_name = st.text_input("写出文件名", value="output.inx")

    if st.button("导入 / (重新)开始会话", type="primary", disabled=obj_file is None):
        obj_path = os.path.join(WORKDIR, obj_file.name)
        with open(obj_path, "wb") as f:
            f.write(obj_file.getvalue())
        st.session_state.obj_path = obj_path
        st.session_state.obj_display_name = obj_file.name

        if inx_file is not None:
            inx_path = os.path.join(WORKDIR, inx_file.name)
            with open(inx_path, "wb") as f:
                f.write(inx_file.getvalue())
            st.session_state.doc = gc.load_doc(inx_path)
        else:
            st.session_state.doc = gc.new_empty_doc()

        st.session_state.texture_bytes = texture_file.getvalue() if texture_file is not None else None
        st.session_state.global_rotate = (0.0, 0.0, 0.0)
        st.session_state.y_center = gc.compute_y_center(obj_path, 0.0, 0.0, 0.0)
        st.session_state._parts_cache_key = None
        st.session_state.session_ready = True
        reset_params()
        st.success(f"已导入 {obj_file.name}，y_center_obj = {st.session_state.y_center:.4f}")

if not st.session_state.get("session_ready"):
    st.info("请先导入OBJ并点击「导入 / (重新)开始会话」。")
    st.stop()

obj_path = st.session_state.obj_path
doc = st.session_state.doc


def apply_rotate(verts):
    rx, ry, rz = st.session_state.global_rotate
    if rx or ry or rz:
        return rotate_verts_deg(verts, rx, ry, rz)
    return verts


# ---------------------------------------------------------------------------
# 调整初始模型（全局、一次性，影响本次会话之后的一切）
# ---------------------------------------------------------------------------
with st.container(border=True):
    st.subheader("调整初始模型（全局、一次性——转动动画参照系也会跟着变）")
    rx0, ry0, rz0 = st.session_state.global_rotate
    g1, g2, g3, g4 = st.columns([1, 1, 1, 1])
    grx = g1.number_input("绕X轴(°)", value=rx0, key="global_rx")
    gry = g2.number_input("绕Y轴(°)", value=ry0, key="global_ry")
    grz = g3.number_input("绕Z轴(°)", value=rz0, key="global_rz")
    if g4.button("应用初始旋转"):
        st.session_state.global_rotate = (grx, gry, grz)
        st.session_state.y_center = gc.compute_y_center(obj_path, grx, gry, grz)
        st.session_state._parts_cache_key = None
        st.success(f"已应用，新的 y_center_obj = {st.session_state.y_center:.4f}")
    st.caption(f"当前：X={rx0}° Y={ry0}° Z={rz0}°　|　y_center_obj = {st.session_state.y_center:.4f}"
               "（这个值在导入/应用旋转时算一次，之后所有部件写入操作统一复用，"
               "不会各自重新计算，避免多部件相对位置错位）")

# ---------------------------------------------------------------------------
# 三栏主区域
# ---------------------------------------------------------------------------
left, mid, right = st.columns([1.1, 1.3, 1.1])

# ---- 左栏：笼子构筑参数 ----
with left:
    st.subheader("参数")
    if st.button("重置为默认值"):
        reset_params()
        st.rerun()

    st.selectbox("笼子构筑方式", ["cylinder", "full-topology", "full-topology-uv"],
                 key="p_cage_method",
                 index=["cylinder", "full-topology", "full-topology-uv"].index(pget("cage_method")))
    cage_method = pget("cage_method")

    node_type_options = ["meshgroup", "part"] if cage_method != "full-topology" else ["meshgroup"]
    if pget("node_type") not in node_type_options:
        st.session_state["p_node_type"] = "meshgroup"
    st.selectbox("节点类型", node_type_options, key="p_node_type",
                 index=node_type_options.index(pget("node_type")))
    node_type = pget("node_type")
    if cage_method == "full-topology":
        st.caption("full-topology(正交投影)不支持part模式，没有真实UV数据")

    st.selectbox("部件分组方式(--group-by)", ["object", "material", "object_material"],
                 key="p_group_by",
                 index=["object", "material", "object_material"].index(pget("group_by")))
    group_by = pget("group_by")

    st.number_input("scale(OBJ米->像素)", key="p_scale", value=pget("scale"))
    scale = pget("scale")

    if cage_method == "cylinder":
        st.number_input("cols(柱面展开列数)", key="p_cols", value=pget("cols"), step=1)
        rows_override = st.checkbox("手动指定rows(不勾选=自动按正方形格子算)",
                                     key="p_rows_override", value=pget("rows_override"))
        if rows_override:
            st.number_input("rows", key="p_rows", value=pget("rows"), step=1)
        st.number_input("expand_frac(y范围外扩比例)", key="p_expand_frac", value=pget("expand_frac"))
        ray_radius_override = st.checkbox("手动指定ray_radius(不勾选=自动估算)",
                                           key="p_ray_radius_override", value=pget("ray_radius_override"))
        if ray_radius_override:
            st.number_input("ray_radius", key="p_ray_radius", value=pget("ray_radius"))
        st.number_input("radius_margin(自动估算半径的安全系数)", key="p_radius_margin",
                         value=pget("radius_margin"))

    if cage_method == "full-topology":
        st.selectbox("facing(贴图朝向)", ["front", "back"], key="p_facing",
                     index=["front", "back"].index(pget("facing")))
        st.number_input("z_threshold", key="p_z_threshold", value=pget("z_threshold"))

    if cage_method == "full-topology-uv" and node_type == "part":
        texel_override = st.checkbox("手动指定texel_density(不勾选=按贴图/3D尺寸自动算，"
                                      "多个part要统一时才需要手动填同一个值)",
                                      key="p_texel_density_override", value=pget("texel_density_override"))
        if texel_override:
            st.number_input("texel_density", key="p_texel_density", value=pget("texel_density"))

    st.markdown("---")
    st.caption("Turn / Roll 幅度与断点数(新建deformer时用；绑定进已有deformer时断点数"
               "自动复用目标，这里的bp设置不生效)")
    st.number_input("yaw_range(°)", key="p_yaw_range", value=pget("yaw_range"))
    st.number_input("pitch_range(°)", key="p_pitch_range", value=pget("pitch_range"))
    if cage_method != "full-topology-uv":
        st.number_input("roll_range(°)", key="p_roll_range", value=pget("roll_range"))
    st.number_input("yaw_bp", key="p_yaw_bp", value=pget("yaw_bp"), step=1)
    st.number_input("pitch_bp", key="p_pitch_bp", value=pget("pitch_bp"), step=1)
    if cage_method != "full-topology-uv":
        st.number_input("roll_bp", key="p_roll_bp", value=pget("roll_bp"), step=1)

# ---- 中栏：OBJ部件列表 ----
with mid:
    st.subheader("OBJ 部件")
    cache_key = (cage_method, group_by)
    if st.session_state.get("_parts_cache_key") != cache_key:
        st.session_state._parts_cache = gc.list_parts(obj_path, cage_method, group_by)
        st.session_state._parts_cache_key = cache_key
    parts = st.session_state._parts_cache

    part_options = ["(整个OBJ，不拆分)"] + list(parts.keys())
    selected_part = st.selectbox("选择部件", part_options, key="selected_part")

    if selected_part == "(整个OBJ，不拆分)":
        whole = gc.whole_model(obj_path, cage_method, group_by)
        cur_verts, cur_faces, cur_uvs = whole["verts"], whole["faces"], whole["uvs"]
        default_name = st.session_state.obj_display_name.rsplit(".", 1)[0]
    else:
        p = parts[selected_part]
        cur_verts, cur_faces, cur_uvs = p["verts"], p["faces"], p["uvs"]
        default_name = selected_part

    st.write(f"顶点数: **{len(cur_verts)}**　三角面数: **{len(cur_faces)}**"
             + ("　（有UV）" if cur_uvs is not None else "　（无UV）"))

    if cur_uvs is not None:
        if st.button("诊断：这个组内部是否碎片化(UV连通性)"):
            diag = gc.diagnose_fragments(cur_verts, cur_faces, cur_uvs)
            st.write(f"拆出 **{diag['island_count']}** 个UV连通island：")
            for isl in diag["islands"][:8]:
                st.caption(f"面数={isl['face_count']}　顶点数={isl['vert_count']}　"
                           f"3D中心={[round(x, 3) for x in isl['center_3d']]}　"
                           f"y范围={[round(y, 3) for y in isl['y_range']]}")
            if diag["island_count"] > 1:
                st.warning("这个组内部不止一块连通区域——如果这些island的3D中心/y范围"
                           "分散在模型不同位置，说明是多个不相关碎片拼在一起，用现有的"
                           "trans/deform公式不可能同时摆对所有碎片的位置，需要手动按"
                           "更细的--group-by(material/object_material)重新分组，或者"
                           "在Blender里把这几块拆成独立物体。")

# ---- 右栏：已有deformer ----
with right:
    st.subheader("已有 Deformer")
    turn_params, roll_params = gc.list_existing_params(doc)
    st.write(f"**Turn (yaw+pitch)：** {len(turn_params)} 个")
    for p in turn_params:
        st.caption(f"「{p['name']}」— 已绑定{len(set(b['node'] for b in p['bindings']))}个节点")
    st.write(f"**Roll：** {len(roll_params)} 个")
    for p in roll_params:
        st.caption(f"「{p['name']}」— 已绑定{len(set(b['node'] for b in p['bindings']))}个节点")
    st.write("**节点树：**")
    for n in gc.list_node_names(doc):
        st.caption(n)

# ---------------------------------------------------------------------------
# 底部：写入操作
# ---------------------------------------------------------------------------
st.markdown("---")
st.subheader("写入操作")

w1, w2 = st.columns(2)
with w1:
    write_name = st.text_input("节点/参数名", value=default_name, key="write_name")
with w2:
    parent_options = ["(挂在Root下)"] + gc.list_node_names(doc)
    parent_choice = st.selectbox("挂载到已有节点下(可选)", parent_options, key="parent_choice")
    parent_name = None if parent_choice == "(挂在Root下)" else parent_choice

# ---- 笼子朝向(仅本次操作，cylinder/full-topology有效) ----
cage_rotate_x = cage_rotate_y = cage_rotate_z = 0.0
if cage_method in ("cylinder", "full-topology"):
    with st.expander("笼子朝向(仅本次操作，不影响转动动画参照系——hair_back/侧面用这个)", expanded=False):
        qc1, qc2, qc3, qc4 = st.columns(4)
        if qc1.button("前(0°)"):
            st.session_state["cage_rot_y"] = 0.0
        if qc2.button("后(180°)"):
            st.session_state["cage_rot_y"] = 180.0
        if qc3.button("左侧(90°)"):
            st.session_state["cage_rot_y"] = 90.0
        if qc4.button("右侧(-90°)"):
            st.session_state["cage_rot_y"] = -90.0
        cr1, cr2, cr3 = st.columns(3)
        cage_rotate_x = cr1.number_input("X角度", value=st.session_state.get("cage_rot_x", 0.0), key="cage_rot_x")
        cage_rotate_y = cr2.number_input("Y角度", value=st.session_state.get("cage_rot_y", 0.0), key="cage_rot_y")
        cage_rotate_z = cr3.number_input("Z角度", value=st.session_state.get("cage_rot_z", 0.0), key="cage_rot_z")
elif cage_method == "full-topology-uv":
    st.caption("full-topology-uv的笼子形状完全由UV决定，「笼子朝向」在这个模式下不生效。")

# ---- Turn ----
t1, t2, t3 = st.columns([1, 1.2, 1])
with t1:
    create_turn = st.checkbox("生成/绑定 Turn(yaw+pitch)", value=True, key="create_turn")
with t2:
    turn_target_options = ["(新建)"] + [p["name"] for p in turn_params]
    turn_target_choice = st.selectbox("Turn 目标", turn_target_options, key="turn_target",
                                       disabled=not create_turn)
with t3:
    yaw_dir = st.selectbox("yaw方向", ["both", "neg", "pos"], key="yaw_dir", disabled=not create_turn)
    pitch_dir = st.selectbox("pitch方向", ["both", "neg", "pos"], key="pitch_dir", disabled=not create_turn)

# ---- Roll ----
if cage_method == "full-topology-uv":
    st.caption("full-topology-uv模式不生成roll(需要的话请在Inochi Creator里手动加)。")
    create_roll = False
    roll_target_choice = "(新建)"
    roll_dir = "both"
else:
    r1, r2, r3 = st.columns([1, 1.2, 1])
    with r1:
        create_roll = st.checkbox("生成/绑定 Roll", value=True, key="create_roll")
    with r2:
        roll_target_options = ["(新建)"] + [p["name"] for p in roll_params]
        roll_target_choice = st.selectbox("Roll 目标", roll_target_options, key="roll_target",
                                           disabled=not create_roll)
    with r3:
        roll_dir = st.selectbox("roll方向", ["both", "neg", "pos"], key="roll_dir", disabled=not create_roll)

st.markdown("")
if st.button("✅ 确认写入这个部件", type="primary"):
    verts = apply_rotate(cur_verts)
    turn_target_param = None
    if create_turn and turn_target_choice != "(新建)":
        turn_target_param = next(p for p in turn_params if p["name"] == turn_target_choice)
    roll_target_param = None
    if create_roll and roll_target_choice != "(新建)":
        roll_target_param = next(p for p in roll_params if p["name"] == roll_target_choice)

    kwargs = dict(
        obj_verts=verts, obj_faces=cur_faces, obj_uvs=cur_uvs,
        name=write_name, parent_name=parent_name,
        y_center_obj=st.session_state.y_center,
        cage_method=cage_method, node_type=node_type, scale=scale,
        cols=int(pget("cols")), rows=(int(pget("rows")) if pget("rows_override") else None),
        expand_frac=pget("expand_frac"),
        ray_radius=(pget("ray_radius") if pget("ray_radius_override") else None),
        radius_margin=pget("radius_margin"),
        facing=pget("facing"), z_threshold=pget("z_threshold"),
        cage_rotate_x=cage_rotate_x, cage_rotate_y=cage_rotate_y, cage_rotate_z=cage_rotate_z,
        texture_bytes=st.session_state.texture_bytes,
        texel_density=(pget("texel_density") if pget("texel_density_override") else None),
        create_turn=create_turn, turn_target_param=turn_target_param,
        yaw_range=pget("yaw_range"), pitch_range=pget("pitch_range"),
        yaw_bp=int(pget("yaw_bp")), pitch_bp=int(pget("pitch_bp")),
        yaw_dir=yaw_dir, pitch_dir=pitch_dir,
        create_roll=create_roll, roll_target_param=roll_target_param,
        roll_range=pget("roll_range"), roll_bp=int(pget("roll_bp")), roll_dir=roll_dir,
    )
    write_error = None
    result = None
    try:
        result = gc.process_part(doc, **kwargs)
    except Exception as e:
        write_error = e

    if write_error is not None:
        st.error(f"写入失败：{write_error}")
    else:
        msg = f"已写入「{result.node_name}」，笼子顶点数={result.vert_count}"
        if result.texel_density_used:
            msg += f"，texel_density={result.texel_density_used:.1f}"
        st.success(msg)
        if result.roll_skipped_reason:
            st.info(result.roll_skipped_reason)
        st.rerun()  # 放在try/except之外

# ---------------------------------------------------------------------------
# 导出
# ---------------------------------------------------------------------------
st.markdown("---")
st.subheader("导出")
st.caption("下面两种方式都可以拿到当前的.inx——「下载」走浏览器下载(存到浏览器默认的"
           "下载目录，通常是 Downloads 文件夹)；「直接保存到路径」是Python在你运行"
           "streamlit的这台机器上直接把文件写到你指定的完整路径，更适合本地跑的场景。")

export_path = os.path.join(WORKDIR, output_name if output_name.endswith((".inx", ".inp")) else output_name + ".inx")
gc.write_inx(export_path, doc)
with open(export_path, "rb") as f:
    st.download_button("⬇️ 下载当前 .inx(存到浏览器下载目录)", data=f.read(),
                        file_name=os.path.basename(export_path))

st.write("**或者直接保存到本地路径：**")
save_col1, save_col2 = st.columns([3, 1])
default_save_path = os.path.join(os.path.expanduser("~"), output_name
                                  if output_name.endswith((".inx", ".inp")) else output_name + ".inx")
save_path = save_col1.text_input("完整保存路径", value=default_save_path, key="save_path")
if save_col2.button("💾 保存到这个路径"):
    try:
        gc.write_inx(save_path, doc)
        st.success(f"已保存到 {save_path}")
    except Exception as e:
        st.error(f"保存失败：{e}（检查目录是否存在、有没有写入权限）")
