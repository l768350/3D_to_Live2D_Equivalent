# -*- coding: utf-8 -*-
"""
gui_core.py
------------
GUI(app.py/Streamlit)和核心逻辑(add_obj_deformer.py等)之间的胶水层。

不修改任何原始核心文件——这里只是把add_obj_deformer.py::main()里"给定一个已经
选好的part+一堆参数，生成笼子+绑定Turn/Roll+追加进doc"这部分逻辑抽出来，改造成
一个可以被多次调用的函数(process_part)，而不是每次都重新走一遍argparse+
重新打开文件+重新读取OBJ的完整CLI流程。

这么做的核心原因：GUI是"选一个part→确认→写入"这样连续多次调用的模式(不是CLI那样
一次调用只处理一个part就退出)，如果直接shell出去调CLI，每次调用都会各自独立重新
计算y_center_obj(从当前这次传入的verts自己的bbox中心算)，多个part分开调用时会
算出不同的基准点，导致相对位置错位。这里改成GUI层只在"导入OBJ/全局旋转变化"时
计算一次y_center_obj，之后所有part操作复用同一个值，从根源上避免这个问题，不需要
改动底层任何一个函数的签名。
"""
import os
import sys

import numpy as np
from PIL import Image
import io as _io

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from obj_head_model import (
    load_obj, load_obj_parts, load_obj_parts_uv, load_obj_uv, load_obj_islands_uv,
    split_uv_islands, rotate_verts_deg,
)
from obj_pipeline import (
    build_standalone_meshgroup, build_standalone_meshgroup_full_topology,
    build_standalone_meshgroup_full_topology_uv,
    build_yaw_pitch_param, build_roll_param,
    bind_turn_to_existing, bind_roll_to_existing,
)
from node_builder import new_uuid, register_existing_uuids
from inx_container import read_inx, write_inx, InxDocument, TextureEntry
from add_obj_deformer import (
    find_node, collect_uuids, find_param_by_name, collect_node_names, dedupe_name,
)


# ---------------------------------------------------------------------------
# 文档(doc)生命周期
# ---------------------------------------------------------------------------

def new_empty_doc() -> InxDocument:
    """新建一个只有Root节点的最小.inx文档，等价于add_obj_deformer.py不传--in时的行为。"""
    root = {
        "uuid": new_uuid(), "name": "Root", "type": "Node", "enabled": True, "zsort": 0.0,
        "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False, "children": [],
    }
    payload = {
        "meta": {"name": "obj_deformer_gui", "version": "custom-tool-0.1", "rigger": None,
                  "artist": None, "rights": None, "copyright": None, "licenseURL": None,
                  "contact": None, "reference": None, "thumbnailId": 4294967295,
                  "preservePixels": False},
        "physics": {"pixelsPerMeter": 1000.0, "gravity": 9.8},
        "nodes": root, "param": [], "automation": [], "animations": {},
    }
    return InxDocument(payload=payload, textures=[])


def load_doc(path: str) -> InxDocument:
    """读取一个已有.inx，并把里面的uuid注册进全局已用集合(避免新生成的uuid撞车)。"""
    doc = read_inx(path)
    uuids = set()
    collect_uuids(doc.payload["nodes"], uuids)
    register_existing_uuids(uuids)
    return doc


# ---------------------------------------------------------------------------
# OBJ读取(部件列表/整体)
# ---------------------------------------------------------------------------

def list_parts(obj_path: str, cage_method: str, group_by: str):
    """按当前cage-method决定要不要连带UV一起读，返回
    OrderedDict: 部件名 -> {"verts", "faces", "uvs"(可能是None)}"""
    if cage_method == "full-topology-uv":
        raw = load_obj_parts_uv(obj_path, group_by=group_by)
        return {k: {"verts": v[0], "faces": v[1], "uvs": v[2]} for k, v in raw.items()}
    raw = load_obj_parts(obj_path, group_by=group_by)
    return {k: {"verts": v[0], "faces": v[1], "uvs": None} for k, v in raw.items()}


def whole_model(obj_path: str, cage_method: str, group_by: str):
    """--part不传时(把整个OBJ当一个模型处理)的等价读取。"""
    if cage_method == "full-topology-uv":
        v, f, uv = load_obj_uv(obj_path, group_by=group_by)
        return {"verts": v, "faces": f, "uvs": uv}
    v, f = load_obj(obj_path)
    return {"verts": v, "faces": f, "uvs": None}


def compute_y_center(obj_path: str, rotate_x: float, rotate_y: float, rotate_z: float) -> float:
    """全局y_center_obj：用整个模型(不是某个part)的顶点范围算，应用过全局旋转之后。
    这个值应该在"导入OBJ"或"应用初始模型旋转"时算一次，之后所有part操作复用，
    不要在每个part操作里各自用那个part自己的verts重新算。"""
    verts, _ = load_obj(obj_path)
    if rotate_x or rotate_y or rotate_z:
        verts = rotate_verts_deg(verts, rotate_x, rotate_y, rotate_z)
    return float((verts[:, 1].min() + verts[:, 1].max()) / 2.0)


def diagnose_fragments(verts: np.ndarray, faces: np.ndarray, uvs, min_faces: int = 1):
    """对一个已选中的part跑UV island连通分量分析，用来提示"这个组是不是内部混了
    好几块不相关的碎片"（不产出任何节点，纯诊断）。没有UV数据时返回None。"""
    if uvs is None:
        return None
    islands = split_uv_islands(verts, faces, uvs, min_faces=min_faces)
    islands_info = []
    for iv, ifac, _iuv in islands:
        islands_info.append({
            "face_count": len(ifac),
            "vert_count": len(iv),
            "center_3d": iv.mean(axis=0).tolist(),
            "y_range": [float(iv[:, 1].min()), float(iv[:, 1].max())],
        })
    islands_info.sort(key=lambda x: x["face_count"], reverse=True)
    return {"island_count": len(islands_info), "islands": islands_info}


# ---------------------------------------------------------------------------
# 核心：处理一个part，生成笼子+Turn/Roll绑定，追加进doc
# ---------------------------------------------------------------------------

class PartWriteResult:
    def __init__(self, node_name, vert_count, texel_density_used, roll_skipped_reason=None):
        self.node_name = node_name
        self.vert_count = vert_count
        self.texel_density_used = texel_density_used
        self.roll_skipped_reason = roll_skipped_reason


def process_part(
    doc: InxDocument,
    *,
    obj_verts: np.ndarray, obj_faces: np.ndarray, obj_uvs=None,
    name: str,
    parent_name: str = None,
    param_name_prefix: str = None,
    y_center_obj: float,
    # 笼子构筑
    cage_method: str = "cylinder",
    node_type: str = "meshgroup",
    scale: float = 3000.0,
    cols: int = 26, rows: int = None, expand_frac: float = 0.15,
    ray_radius: float = None, radius_margin: float = 1.3,
    facing: str = "front", z_threshold: float = -0.04,
    # 笼子朝向(仅本次操作，cylinder/full-topology有效)
    cage_rotate_x: float = 0.0, cage_rotate_y: float = 0.0, cage_rotate_z: float = 0.0,
    # 贴图(仅node_type=part)
    texture_bytes: bytes = None,
    texel_density: float = None,
    # Turn
    create_turn: bool = True,
    turn_target_param: dict = None,  # None=新建；传已有的Turn参数dict=绑定进去
    yaw_range: float = 40.0, pitch_range: float = 25.0,
    yaw_bp: int = 9, pitch_bp: int = 5,
    yaw_dir: str = "both", pitch_dir: str = "both",
    # Roll
    create_roll: bool = True,
    roll_target_param: dict = None,  # None=新建；传已有的Roll参数dict=绑定进去
    roll_range: float = 15.0, roll_bp: int = 5, roll_dir: str = "both",
) -> PartWriteResult:
    """等价于add_obj_deformer.py main()里"读完OBJ之后"的全部逻辑，但参数是显式
    传入(不是从argparse.Namespace读)，且y_center_obj必须由调用方传入(不在这里
    临时算)——这是修掉"多part分开调用各自算出不同基准点"这个隐患的关键。"""
    root = doc.payload["nodes"]
    params = doc.payload.setdefault("param", [])
    textures = doc.textures

    # ---- 挂载点 ----
    parent_node = root
    if parent_name:
        found = find_node(root, parent_name)
        if found is not None:
            parent_node = found

    # ---- 重名检测 ----
    existing_node_names = set()
    collect_node_names(root, existing_node_names)
    if name in existing_node_names:
        name = dedupe_name(existing_node_names, name)

    # ---- 真实贴图裁剪(仅full-topology-uv + node_type=part + 传了贴图) ----
    real_tex_bytes = None
    real_tex_w = real_tex_h = None
    deform_scale = scale
    local_obj_uvs = obj_uvs
    if node_type == "part" and texture_bytes is not None:
        with Image.open(_io.BytesIO(texture_bytes)) as _im:
            _im = _im.convert("RGBA")
            orig_w, orig_h = _im.size
            if cage_method == "full-topology-uv":
                u_min, u_max = float(local_obj_uvs[:, 0].min()), float(local_obj_uvs[:, 0].max())
                v_min, v_max = float(local_obj_uvs[:, 1].min()), float(local_obj_uvs[:, 1].max())
                px0 = max(0, int(u_min * orig_w))
                px1 = min(orig_w, int(u_max * orig_w) + 1)
                py0 = max(0, int((1.0 - v_max) * orig_h))
                py1 = min(orig_h, int((1.0 - v_min) * orig_h) + 1)
                cropped = _im.crop((px0, py0, px1, py1))
                real_tex_w, real_tex_h = cropped.size
                _buf = _io.BytesIO()
                cropped.save(_buf, format="PNG")
                real_tex_bytes = _buf.getvalue()
                u_min_exact, u_max_exact = px0 / orig_w, px1 / orig_w
                v_min_exact, v_max_exact = 1.0 - py1 / orig_h, 1.0 - py0 / orig_h
                local_obj_uvs = local_obj_uvs.copy()
                local_obj_uvs[:, 0] = (local_obj_uvs[:, 0] - u_min_exact) / (u_max_exact - u_min_exact)
                local_obj_uvs[:, 1] = (local_obj_uvs[:, 1] - v_min_exact) / (v_max_exact - v_min_exact)
                if texel_density is not None:
                    used_texel_density = texel_density
                else:
                    x_extent = float(obj_verts[:, 0].max() - obj_verts[:, 0].min())
                    y_extent = float(obj_verts[:, 1].max() - obj_verts[:, 1].min())
                    ratios = []
                    if x_extent > 1e-9:
                        ratios.append(real_tex_w / x_extent)
                    if y_extent > 1e-9:
                        ratios.append(real_tex_h / y_extent)
                    used_texel_density = sum(ratios) / len(ratios) if ratios else scale
                deform_scale = used_texel_density
            else:
                real_tex_w, real_tex_h = orig_w, orig_h
                real_tex_bytes = texture_bytes
                used_texel_density = None
    else:
        used_texel_density = None

    # ---- 生成笼子 ----
    has_cage_rotate = bool(cage_rotate_x or cage_rotate_y or cage_rotate_z)
    if cage_method == "full-topology-uv":
        mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes, mirror_x = build_standalone_meshgroup_full_topology_uv(
            obj_verts, obj_faces, local_obj_uvs, name=name, node_type=node_type,
            tex_width=real_tex_w, tex_height=real_tex_h,
        )
    else:
        cage_build_verts = (
            rotate_verts_deg(obj_verts, cage_rotate_x, cage_rotate_y, cage_rotate_z)
            if has_cage_rotate else obj_verts
        )
        if cage_method == "full-topology":
            mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes, mirror_x = build_standalone_meshgroup_full_topology(
                cage_build_verts, obj_faces, scale, y_center_obj,
                facing=facing, z_threshold=z_threshold, name=name, node_type=node_type,
            )
        else:
            mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes = build_standalone_meshgroup(
                cage_build_verts, obj_faces, scale, y_center_obj, (obj_verts[:, 1].min(), obj_verts[:, 1].max()),
                cols=cols, rows=rows, expand_frac=expand_frac,
                ray_radius=ray_radius, radius_margin=radius_margin, name=name, node_type=node_type,
            )
            mirror_x = False
        if has_cage_rotate:
            cage_obj_xyz = rotate_verts_deg(
                cage_obj_xyz, cage_rotate_x, cage_rotate_y, cage_rotate_z, inverse=True,
            )

    if real_tex_bytes is not None:
        tex_bytes = real_tex_bytes
    if tex_bytes is not None:
        tex_index = len(textures)
        textures.append(TextureEntry(data=tex_bytes, encoding=0))
        mg["textures"][0] = tex_index
    parent_node.setdefault("children", []).append(mg)

    # ---- Turn(yaw+pitch, vec2) ----
    param_prefix = param_name_prefix or name
    if create_turn:
        if turn_target_param is not None:
            bind_turn_to_existing(
                turn_target_param, mg["uuid"], cage_obj_xyz, cage_orig_px, cage_orig_py, mirror_x,
                deform_scale, y_center_obj, yaw_range, pitch_range, pitch_flip=True,
                yaw_dir=yaw_dir, pitch_dir=pitch_dir,
            )
        else:
            existing_names = {p.get("name") for p in params}
            turn_name = dedupe_name(existing_names, f"{param_prefix}:: Turn")
            yaw_pitch_param = build_yaw_pitch_param(
                [(mg["uuid"], cage_obj_xyz, cage_orig_px, cage_orig_py, mirror_x)],
                deform_scale, y_center_obj, yaw_range, pitch_range,
                yaw_bp, pitch_bp, pitch_flip=True, name=turn_name,
                yaw_dir=yaw_dir, pitch_dir=pitch_dir,
            )
            params.append(yaw_pitch_param)

    # ---- Roll(纯旋转) ----
    roll_skipped_reason = None
    if cage_method == "full-topology-uv":
        # 核心逻辑里full-topology-uv始终不生成roll(UV空间旋转原点问题未实测验证过)，
        # GUI这边跟CLI保持一致，不做任何绕过。
        roll_skipped_reason = "full-topology-uv模式暂不支持roll，请在Inochi Creator里手动加"
    elif create_roll:
        if roll_target_param is not None:
            bind_roll_to_existing(roll_target_param, mg["uuid"], roll_range, roll_dir=roll_dir)
        else:
            existing_names = {p.get("name") for p in params}
            roll_name = dedupe_name(existing_names, f"{param_prefix}:: Roll")
            roll_param = build_roll_param(mg["uuid"], roll_range, roll_bp, name=roll_name, roll_dir=roll_dir)
            params.append(roll_param)

    return PartWriteResult(
        node_name=name, vert_count=len(cage_orig_px),
        texel_density_used=used_texel_density, roll_skipped_reason=roll_skipped_reason,
    )


# ---------------------------------------------------------------------------
# 已有deformer列表(供右栏展示+选择绑定目标)
# ---------------------------------------------------------------------------

def list_existing_params(doc: InxDocument):
    """返回(turn_params, roll_params)两个列表，元素是原始param dict(可直接传给
    process_part的turn_target_param/roll_target_param)。"""
    params = doc.payload.get("param", [])
    turn_params = [p for p in params if p.get("is_vec2")]
    roll_params = [p for p in params if not p.get("is_vec2")]
    return turn_params, roll_params


def list_node_names(doc: InxDocument):
    names = set()
    collect_node_names(doc.payload["nodes"], names)
    return sorted(names)
