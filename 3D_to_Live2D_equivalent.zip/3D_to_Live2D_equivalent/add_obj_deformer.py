"""
add_obj_deformer.py
----------------------
命令行工具：读取一个OBJ格式的3D模型，往Inochi2D的puppet文件(.inx)里插入
一个对应的deformer节点(MeshGroup或Part)，以及Turn(yaw/pitch)/Roll参数
绑定。贴图绘制和最终的部件摆放留给美术在Inochi Creator里手动完成，本工具
只负责生成笼子网格，以及根据真实3D旋转算出的deform数据。

支持三种笼子构筑方式(--cage-method)：
  cylinder         (默认)绕Y轴柱面展开，生成规整的cols×rows网格，覆盖
                    模型完整的360度表面(含背面)。
  full-topology     直接复用模型自身的顶点和三角面当笼子，可选正面/背面
                    过滤(--facing)。
  full-topology-uv  复用模型自身的顶点/三角面，笼子的静止布局用模型自带
                    的UV坐标——这样Part节点可以直接用源模型自己的贴图
                    (见--texture-file)。

OBJ可以按Blender物体名、材质名，或两者复合(--group-by)拆分成多个部件；
另外提供了一个基于UV连通性的island检测工具，用来诊断/进一步拆分那些内部
并非一整块连贯表面的分组。

不传--name时，新节点和参数名默认取OBJ文件名(不含扩展名)；不传--parent时
直接挂在Root节点下面。

用法：
    python3 add_obj_deformer.py --obj model.obj --out result.inx
    python3 add_obj_deformer.py --obj model.obj --in existing.inx --out result.inx \
        --name "Head" --parent "Neck"

不传--in就新建一个最小化的.inx(只有Root节点)。传了--in就读取现有文件，把
新节点挂到指定父节点下(不传--parent就挂Root下)，新参数追加进现有参数列表，
不会改动已有的节点/参数。
"""
import os
import sys
import argparse
sys.path.insert(0, '.')

from obj_head_model import (
    load_obj, load_obj_parts, load_obj_parts_uv, load_obj_uv, rotate_verts_deg,
)
from obj_pipeline import (
    build_standalone_meshgroup, build_standalone_meshgroup_full_topology,
    build_standalone_meshgroup_full_topology_uv,
    build_yaw_pitch_param, build_roll_param,
    bind_turn_to_existing, bind_roll_to_existing,
)
from node_builder import new_uuid, register_existing_uuids
from inx_container import read_inx, write_inx, InxDocument, TextureEntry


def find_node(node: dict, name: str):
    """在节点树里按名字找节点(深度优先)，找不到返回None。"""
    if node.get("name") == name:
        return node
    for c in node.get("children", []):
        found = find_node(c, name)
        if found is not None:
            return found
    return None


def collect_uuids(node: dict, acc: set):
    acc.add(node["uuid"])
    for c in node.get("children", []):
        collect_uuids(c, acc)


def find_param_by_name(params: list, name: str):
    """在参数列表里按名字找参数，找不到返回None。"""
    for p in params:
        if p.get("name") == name:
            return p
    return None


def collect_node_names(node: dict, acc: set):
    if node.get("name"):
        acc.add(node["name"])
    for c in node.get("children", []):
        collect_node_names(c, acc)


def dedupe_name(existing_names: set, base_name: str) -> str:
    """如果base_name已经在existing_names里，自动加(2)/(3)...后缀直到不重复。"""
    if base_name not in existing_names:
        return base_name
    i = 2
    while f"{base_name} ({i})" in existing_names:
        i += 1
    return f"{base_name} ({i})"


def main():
    ap = argparse.ArgumentParser(description="往.inx里插入一个OBJ驱动的MeshGroup笼子+yaw/pitch/roll绑定")
    ap.add_argument("--obj", required=True, help="OBJ模型路径")
    ap.add_argument("--group-by", choices=["object", "material", "object_material"], default="object",
                     help="--list-parts/--part按什么分组：object(默认，按Blender物体/o标记)、"
                          "material(按usemtl材质名，同材质但分属不同物体的会被合并成一组)、"
                          "object_material(物体名::材质名两级复合分组，最精细，能精确抠出"
                          "\"某个物体里属于某种材质的那部分\"，不会像material模式那样把不同"
                          "物体但同材质的东西混在一起)。同一个物体经常混了好几种材质"
                          "(比如皮肤+被遮住的衣服)，这种情况用material或object_material能拆得更细")
    ap.add_argument("--list-parts", action="store_true",
                     help="列出OBJ里按--group-by分组识别到的部件名字+顶点/面数，不生成任何东西(--out可以不传)")
    ap.add_argument("--part", default=None,
                     help="只处理OBJ里指定名字的部件(配合--list-parts先看有哪些名字可选，"
                          "名字是按--group-by分组得到的)；不传就把整个OBJ当一个模型处理(向后兼容)")
    ap.add_argument("--in", dest="input_inx", default=None, help="已有的.inx文件(不传就新建)")
    ap.add_argument("--out", default=None, help="输出.inx路径(--list-parts时可以不传)")
    ap.add_argument("--name", default=None, help="新MeshGroup的名字，不传就用OBJ文件名(不含扩展名)")
    ap.add_argument("--parent", default=None, help="挂在现有.inx里哪个节点下面(按名字找，不传就挂Root下)")
    ap.add_argument("--param-name", default=None, help="Turn/Roll参数名前缀，不传就用--name")
    ap.add_argument("--scale", type=float, default=3000.0, help="OBJ米->像素的换算比例")
    ap.add_argument("--cols", type=int, default=26)
    ap.add_argument("--rows", type=int, default=None,
                     help="笼子行数(高度方向格子数)。不传就按--cols和柱面周长/高度的实际比例"
                          "自动算出能让格子长宽相等(正方形)的行数；显式传值会强制用这个行数"
                          "(可能格子不是正方形)")
    ap.add_argument("--node-type", choices=["meshgroup", "part"], default="meshgroup",
                     help="输出节点类型。meshgroup(默认)：笼子本身不显示，只用来给挂在它下面的"
                          "子级Part提供deform；part：直接生成一个可显示的图层，网格拓扑和deform"
                          "绑定跟meshgroup完全一样。cylinder和full-topology-uv支持part模式"
                          "(full-topology-uv的part会用真实UV，方便贴自己已有的贴图对齐)，"
                          "full-topology(正交投影)不支持part(没有真实UV数据)")
    ap.add_argument("--cage-method", choices=["cylinder", "full-topology", "full-topology-uv"], default="cylinder",
                     help="笼子构筑方式。cylinder(默认)：绕Y轴360度柱面展开，规整cols×rows网格，"
                          "适合大致围绕一根中心轴分布的形状(头/身体躯干)；full-topology：直接用"
                          "模型自己的顶点+三角面当笼子(不重新采样)，形状贴合模型轮廓不规则，"
                          "适合柱面展开会畸变的不规则/扁平部件(一撮头发、配饰)，只支持"
                          "--node-type meshgroup；full-topology-uv：跟full-topology一样直接用"
                          "模型自己的拓扑，但静止姿势的2D展开直接用OBJ自带的UV坐标(要求OBJ本身"
                          "有UV数据)，展开形状完全由你建模时排的UV决定，最可控，支持meshgroup"
                          "和part两种node-type；**这个方法不会生成roll绑定**(roll的旋转原点在"
                          "UV空间下不对，效果不对，需要roll的话请在Inochi Creator里手动加)")
    ap.add_argument("--expand-frac", type=float, default=0.15, help="笼子的y范围比OBJ的y范围往外扩多少比例(默认15%，仅cylinder)")
    ap.add_argument("--ray-radius", type=float, default=None, help="柱面展开射线起始半径(OBJ单位)，不传就按模型自动估算(仅cylinder)")
    ap.add_argument("--radius-margin", type=float, default=1.3, help="自动估算射线半径时的安全系数(仅cylinder)")
    ap.add_argument("--facing", choices=["front", "back"], default="front",
                     help="仅full-topology：这个部件的贴图是按'看正面'还是'站在模型背后看背面'"
                          "画的。back用于hair_back这类需要展开模型背面的部件，会自动把静止姿势"
                          "的展开左右镜像(不影响真实3D旋转的物理计算)")
    ap.add_argument("--z-threshold", type=float, default=-0.04,
                     help="仅full-topology：z过滤阈值，facing=front时保留z>阈值的顶点(排除纯背面)，"
                          "facing=back时保留z<-阈值的顶点(排除纯正面)。阈值越小保留越多")
    ap.add_argument("--texture-file", default=None,
                     help="仅--node-type part时有效：用这张图片文件(PNG)当贴图，不传就用灰色占位图")
    ap.add_argument("--texel-density", type=float, default=None,
                     help="仅full-topology-uv+part+传了--texture-file时：真实3D坐标换算成"
                          "trans定位偏移用的\"贴图像素/OBJ单位\"比例。不传就用当前这个部件"
                          "自己的裁剪贴图像素尺寸÷真实3D尺寸自动算一个并打印出来；同一个"
                          "模型如果要连续生成好几个part(比如皮肤+衣服)，第一次跑完后把打印"
                          "出的数值记下来，后续调用都显式传同一个--texel-density，保证几个"
                          "part用统一换算比例、相对位置能对得上(每个part各自自动算可能有"
                          "细微差异，多个part摆在一起时会有轻微错位)")
    ap.add_argument("--yaw-range", type=float, default=40.0)
    ap.add_argument("--pitch-range", type=float, default=25.0)
    ap.add_argument("--roll-range", type=float, default=15.0)
    ap.add_argument("--yaw-bp", type=int, default=9, help="仅新建Turn时有效(绑进已有deformer会复用它的断点数)")
    ap.add_argument("--pitch-bp", type=int, default=5, help="仅新建Turn时有效")
    ap.add_argument("--roll-bp", type=int, default=5, help="仅新建Roll时有效")
    ap.add_argument("--bind-turn", default=None,
                     help="不新建Turn参数，把这个笼子的t.x/t.y/deform绑进--in文件里指定名字的"
                          "已有Turn(vec2)参数(断点数自动复用目标的，不能用--yaw-bp/--pitch-bp改)")
    ap.add_argument("--bind-roll", default=None,
                     help="不新建Roll参数，把这个笼子的transform.r.z绑进--in文件里指定名字的"
                          "已有Roll参数(断点数自动复用目标的，不能用--roll-bp改)")
    ap.add_argument("--yaw-dir", choices=["both", "neg", "pos"], default="both",
                     help="这个部件是否只往一个方向yaw：both(默认，对称)/neg/pos")
    ap.add_argument("--pitch-dir", choices=["both", "neg", "pos"], default="both",
                     help="这个部件是否只往一个方向pitch")
    ap.add_argument("--roll-dir", choices=["both", "neg", "pos"], default="both",
                     help="这个部件是否只往一个方向roll")
    ap.add_argument("--y-min", type=float, default=None, help="采样y范围最小值(OBJ单位)，不传就用整个OBJ的bbox")
    ap.add_argument("--y-max", type=float, default=None)
    ap.add_argument("--rotate-x", type=float, default=0.0, help="处理前先把整个模型绕原点绕X轴转多少度(角度制)——永久调整，会影响这次调用的一切(笼子形状+转动数学+y-range)，适合修正OBJ建模时轴没对齐这类“调整初始模型”的场景")
    ap.add_argument("--rotate-y", type=float, default=0.0, help="处理前先把整个模型绕原点绕Y轴转多少度(角度制)——同上，永久调整")
    ap.add_argument("--rotate-z", type=float, default=0.0, help="处理前先把整个模型绕原点绕Z轴转多少度(角度制)——同上，永久调整")
    ap.add_argument("--cage-rotate-x", type=float, default=0.0,
                     help="只在建笼子这一步临时把模型转个角度(比如180度)，笼子建完后会自动转"
                          "回来再算transform.t.x/t.y/deform——跟--rotate-x的区别：--rotate-x是"
                          "永久改变整个模型的朝向(转动数学也跟着变)，这个只是让笼子\"从另一个"
                          "角度蒙上去\"(比如hair_back要让笼子正中间对应模型背面)，但转头动画的"
                          "参照系还是跟身体其它部位统一，不会带偏")
    ap.add_argument("--cage-rotate-y", type=float, default=0.0, help="同--cage-rotate-x，绕Y轴——hair_back典型用法是这里传180")
    ap.add_argument("--cage-rotate-z", type=float, default=0.0, help="同--cage-rotate-x，绕Z轴")
    args = ap.parse_args()

    if args.list_parts:
        parts = load_obj_parts(args.obj, group_by=args.group_by)
        print(f"{args.obj} 按{args.group_by}分组识别到{len(parts)}个部件(按--part传名字选择处理哪个)：")
        for pname, (pv, pf) in parts.items():
            print(f"  {pname!r}: 顶点={len(pv)} 三角面={len(pf)}")
        return

    if args.out is None:
        ap.error("--out是必须的(除非用--list-parts)")

    if (args.bind_turn or args.bind_roll) and not args.input_inx:
        ap.error("--bind-turn/--bind-roll需要配合--in指定的已有文件一起用(没有--in就没有已有参数可绑)")

    obj_uvs = None
    if args.cage_method == "full-topology-uv":
        if args.part:
            uv_parts = load_obj_parts_uv(args.obj, group_by=args.group_by)
            if args.part not in uv_parts:
                print(f"错误：OBJ里找不到名为{args.part!r}的部件。可选部件：{list(uv_parts.keys())}")
                sys.exit(1)
            obj_verts, obj_faces, obj_uvs = uv_parts[args.part]
        else:
            obj_verts, obj_faces, obj_uvs = load_obj_uv(args.obj, group_by=args.group_by)
        if obj_uvs is None:
            print("错误：这个OBJ(或指定的部件)没有UV数据，不能用--cage-method full-topology-uv")
            sys.exit(1)
    elif args.part:
        parts = load_obj_parts(args.obj, group_by=args.group_by)
        if args.part not in parts:
            print(f"错误：OBJ里找不到名为{args.part!r}的部件。可选部件：{list(parts.keys())}")
            sys.exit(1)
        obj_verts, obj_faces = parts[args.part]
    else:
        obj_verts, obj_faces = load_obj(args.obj)

    if args.rotate_x or args.rotate_y or args.rotate_z:
        obj_verts = rotate_verts_deg(obj_verts, args.rotate_x, args.rotate_y, args.rotate_z)

    y_range = (args.y_min if args.y_min is not None else obj_verts[:, 1].min(),
               args.y_max if args.y_max is not None else obj_verts[:, 1].max())
    y_center_obj = (obj_verts[:, 1].min() + obj_verts[:, 1].max()) / 2.0
    name = args.name or args.part or os.path.splitext(os.path.basename(args.obj))[0]

    # ---- 读取/新建 输入inx ----
    if args.input_inx:
        doc = read_inx(args.input_inx)
        existing_uuids = set()
        collect_uuids(doc.payload["nodes"], existing_uuids)
        register_existing_uuids(existing_uuids)
        root = doc.payload["nodes"]
        params = doc.payload.get("param", [])
        textures = list(doc.textures)
    else:
        root = {
            "uuid": new_uuid(), "name": "Root", "type": "Node", "enabled": True, "zsort": 0.0,
            "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
            "lockToRoot": False, "children": [],
        }
        params = []
        textures = []
        doc = InxDocument(payload={
            "meta": {"name": "obj_deformer", "version": "custom-tool-0.1", "rigger": None, "artist": None,
                      "rights": None, "copyright": None, "licenseURL": None, "contact": None, "reference": None,
                      "thumbnailId": 4294967295, "preservePixels": False},
            "physics": {"pixelsPerMeter": 1000.0, "gravity": 9.8},
            "nodes": root, "param": params, "automation": [], "animations": {},
        }, textures=textures)

    # ---- 找挂载点 ----
    if args.parent:
        parent_node = find_node(root, args.parent)
        if parent_node is None:
            print(f"警告：在输入文件里找不到名为'{args.parent}'的节点，改挂在Root下")
            parent_node = root
    else:
        parent_node = root

    # ---- 重名检测：新节点名字如果跟已有节点撞了，自动加(2)/(3)...后缀 ----
    existing_node_names = set()
    collect_node_names(root, existing_node_names)
    if name in existing_node_names:
        deduped = dedupe_name(existing_node_names, name)
        print(f"提示：节点名'{name}'已存在，自动改成'{deduped}'")
        name = deduped

    # ---- 如果指定了真实贴图文件，先读出来 ----
    # UV模式+part时，每个Part使用自己独立的、紧贴自身内容裁剪出来的贴图，而不是
    # 共用一整张大图集——这是2D绑骨工具的通用做法。这里把这个部件自己UV包围盒
    # 对应的那部分图集裁出来，做成它专属的小贴图，UV也重新归一化到裁剪后小图的
    # 0~1范围。
    real_tex_bytes = None
    real_tex_w = real_tex_h = None
    deform_scale = args.scale
    if args.node_type == "part" and args.texture_file:
        from PIL import Image as _PILImage
        with _PILImage.open(args.texture_file) as _im:
            _im = _im.convert("RGBA")
            orig_w, orig_h = _im.size
            if args.cage_method == "full-topology-uv":
                u_min, u_max = float(obj_uvs[:, 0].min()), float(obj_uvs[:, 0].max())
                v_min, v_max = float(obj_uvs[:, 1].min()), float(obj_uvs[:, 1].max())
                # 像素裁剪框：v=0在贴图底部/v=1在贴图顶部(OBJ约定)，PIL的y=0在图片顶部
                px0 = max(0, int(u_min * orig_w))
                px1 = min(orig_w, int(u_max * orig_w) + 1)
                py0 = max(0, int((1.0 - v_max) * orig_h))
                py1 = min(orig_h, int((1.0 - v_min) * orig_h) + 1)
                cropped = _im.crop((px0, py0, px1, py1))
                real_tex_w, real_tex_h = cropped.size
                import io as _io
                _buf = _io.BytesIO()
                cropped.save(_buf, format="PNG")
                real_tex_bytes = _buf.getvalue()
                # 用实际裁剪像素框换算回精确的uv边界(避免像素取整误差)，把这个部件的UV
                # 重新归一化到裁剪后小图的0~1范围
                u_min_exact, u_max_exact = px0 / orig_w, px1 / orig_w
                v_min_exact, v_max_exact = 1.0 - py1 / orig_h, 1.0 - py0 / orig_h
                obj_uvs = obj_uvs.copy()
                obj_uvs[:, 0] = (obj_uvs[:, 0] - u_min_exact) / (u_max_exact - u_min_exact)
                obj_uvs[:, 1] = (obj_uvs[:, 1] - v_min_exact) / (v_max_exact - v_min_exact)
                # verts留着UV裁剪形状不动(方便在Edit Mesh里跟贴图对齐)，摆到正确的
                # 3D投影位置这件事完全交给下面的Turn参数(deform)去做——dx=new_px-orig_px
                # 是个恒等式，只要orig_px(这里是verts)和new_px(真实3D投影)用同一套
                # 单位，加起来永远精确等于真实3D投影该有的样子，不需要额外的
                # transform.trans来矫正位置。
                #
                # 关键点：deform算dx用的scale不能用--scale(那是给柱面/正交投影这两种
                # "自己造合成网格"的方法用的、任意选定的"OBJ米数转像素"系数，默认
                # 3000)——verts用的是贴图**真实像素**尺寸，两套单位对不上，混着算会
                # 让静止姿势凭空多出一个巨大偏移。deform要用"贴图像素/OBJ米数"这个
                # 换算比例(texel_density)，从这个部件自己的裁剪贴图像素尺寸÷真实3D
                # 尺寸反推出来(没有--texel-density时)，或者用户显式传入(同一模型
                # 生成多个part时，建议都传同一个值，保证换算比例一致)。
                if args.texel_density is not None:
                    texel_density = args.texel_density
                else:
                    x_extent = float(obj_verts[:, 0].max() - obj_verts[:, 0].min())
                    y_extent = float(obj_verts[:, 1].max() - obj_verts[:, 1].min())
                    ratios = []
                    if x_extent > 1e-9:
                        ratios.append(real_tex_w / x_extent)
                    if y_extent > 1e-9:
                        ratios.append(real_tex_h / y_extent)
                    texel_density = sum(ratios) / len(ratios) if ratios else args.scale
                    print(f"提示：从这个部件的贴图/3D尺寸自动算出texel密度(像素/OBJ单位)="
                          f"{texel_density:.1f}。同一个模型如果还要继续生成其它part，建议"
                          f"后续调用都显式传--texel-density {texel_density:.1f}，保证换算"
                          f"比例统一、相对位置对得上")
                deform_scale = texel_density
            else:
                real_tex_w, real_tex_h = orig_w, orig_h
                with open(args.texture_file, "rb") as f:
                    real_tex_bytes = f.read()

    # ---- 生成笼子 ----
    # cage_build_verts：只在"建笼子"这一步临时转个角度(--cage-rotate-x/y/z)，让笼子
    # 从另一个角度"蒙"上去(比如hair_back转180度让柱面展开正中间对应模型背面)。
    # 这跟--rotate-x/y/z(永久调整整个模型)不一样——建完笼子后要把cage_obj_xyz转回来，
    # 不能让转头动画的参照系也被这个临时视角带偏，否则这个部件转头时会绕着"新正面"
    # 自己转，跟身体其它部位不同步。full-topology-uv的笼子形状完全由UV决定，跟这个
    # 旋转无关，不需要套用这一步。
    has_cage_rotate = bool(args.cage_rotate_x or args.cage_rotate_y or args.cage_rotate_z)
    if args.cage_method == "full-topology-uv":
        # 直接用模型自己的拓扑当笼子，静止姿势的画面位置=(uv-0.5)*贴图像素尺寸(不翻转V轴)；
        # 贴图对齐靠mesh.uvs字段(真实UV，已经重新归一化到裁剪后小图的范围)
        mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes, mirror_x = build_standalone_meshgroup_full_topology_uv(
            obj_verts, obj_faces, obj_uvs, name=name, node_type=args.node_type,
            tex_width=real_tex_w, tex_height=real_tex_h,
        )
    else:
        cage_build_verts = (
            rotate_verts_deg(obj_verts, args.cage_rotate_x, args.cage_rotate_y, args.cage_rotate_z)
            if has_cage_rotate else obj_verts
        )
        if args.cage_method == "full-topology":
            # 直接用模型自己的顶点+三角面当笼子，不重新采样；适合柱面展开会畸变的不规则部件
            mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes, mirror_x = build_standalone_meshgroup_full_topology(
                cage_build_verts, obj_faces, args.scale, y_center_obj,
                facing=args.facing, z_threshold=args.z_threshold, name=name,
                node_type=args.node_type,
            )
        else:
            # 柱面展开(绕Y轴360度打射线)，覆盖整个OBJ含背面；静止形状固定是标准矩形，格子正方形
            mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes = build_standalone_meshgroup(
                cage_build_verts, obj_faces, args.scale, y_center_obj, y_range,
                cols=args.cols, rows=args.rows, expand_frac=args.expand_frac,
                ray_radius=args.ray_radius, radius_margin=args.radius_margin, name=name,
                node_type=args.node_type,
            )
            mirror_x = False
        if has_cage_rotate:
            cage_obj_xyz = rotate_verts_deg(
                cage_obj_xyz, args.cage_rotate_x, args.cage_rotate_y, args.cage_rotate_z, inverse=True,
            )
    if real_tex_bytes is not None:
        tex_bytes = real_tex_bytes
    if tex_bytes is not None:
        tex_index = len(textures)
        textures.append(TextureEntry(data=tex_bytes, encoding=0))
        mg["textures"][0] = tex_index
    parent_node.setdefault("children", []).append(mg)

    # ---- 生成参数绑定(Turn=yaw/pitch合并的vec2参数，Roll=纯旋转) ----
    param_prefix = args.param_name or name

    if args.bind_turn:
        target = find_param_by_name(params, args.bind_turn)
        if target is None:
            print(f"错误：在输入文件里找不到名为{args.bind_turn!r}的参数")
            sys.exit(1)
        if not target.get("is_vec2"):
            print(f"错误：{args.bind_turn!r}不是Turn(vec2)类型的参数，不能绑yaw/pitch数据")
            sys.exit(1)
        bind_turn_to_existing(
            target, mg["uuid"], cage_obj_xyz, cage_orig_px, cage_orig_py, mirror_x,
            deform_scale, y_center_obj, args.yaw_range, args.pitch_range, pitch_flip=True,
            yaw_dir=args.yaw_dir, pitch_dir=args.pitch_dir,
        )
    else:
        existing_param_names = {p.get("name") for p in params}
        turn_name = dedupe_name(existing_param_names, f"{param_prefix}:: Turn")
        yaw_pitch_param = build_yaw_pitch_param(
            [(mg["uuid"], cage_obj_xyz, cage_orig_px, cage_orig_py, mirror_x)],
            deform_scale, y_center_obj, args.yaw_range, args.pitch_range,
            args.yaw_bp, args.pitch_bp, pitch_flip=True, name=turn_name,
            yaw_dir=args.yaw_dir, pitch_dir=args.pitch_dir,
        )
        params.append(yaw_pitch_param)

    if args.cage_method == "full-topology-uv":
        # roll绕节点自身局部原点(0,0)转动。full-topology-uv的verts已经以裁剪后小图的
        # 中心为原点，理论上应该可以正常生成roll，但这条路径还没有实测验证过，先保守
        # 跳过，避免在未确认前生成有风险的绑定。
        if args.bind_roll:
            print("提示：--cage-method full-topology-uv暂不生成roll(尚未验证)，"
                  "已忽略--bind-roll，请在Inochi Creator里手动添加roll")
        else:
            print("提示：--cage-method full-topology-uv暂不生成roll(尚未验证)，"
                  "需要的话请在Inochi Creator里手动添加")
    elif args.bind_roll:
        target = find_param_by_name(params, args.bind_roll)
        if target is None:
            print(f"错误：在输入文件里找不到名为{args.bind_roll!r}的参数")
            sys.exit(1)
        if target.get("is_vec2"):
            print(f"错误：{args.bind_roll!r}是Turn(vec2)类型的参数，不能绑roll数据")
            sys.exit(1)
        bind_roll_to_existing(target, mg["uuid"], args.roll_range, roll_dir=args.roll_dir)
    else:
        existing_param_names = {p.get("name") for p in params}
        roll_name = dedupe_name(existing_param_names, f"{param_prefix}:: Roll")
        roll_param = build_roll_param(mg["uuid"], args.roll_range, args.roll_bp,
                                       name=roll_name, roll_dir=args.roll_dir)
        params.append(roll_param)

    doc.payload["nodes"] = root
    doc.payload["param"] = params
    doc.textures = textures
    write_inx(args.out, doc)
    print(f"完成。笼子顶点数={len(cage_orig_px)}，写入 {args.out}")


if __name__ == "__main__":
    main()
