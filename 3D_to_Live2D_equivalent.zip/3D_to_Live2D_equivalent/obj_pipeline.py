# -*- coding: utf-8 -*-
"""
obj_pipeline.py
------------------
基于OBJ模型驱动的MeshGroup笼子构建函数库：从OBJ读取顶点/面/UV，生成
笼子网格、贴图裁剪、Turn/Roll参数绑定等，供add_obj_deformer.py调用。

核心概念(旧版全自动pipeline，非当前主流程使用)：
- CageRegion：一块"用OBJ表面射线投影驱动形变"的区域(头部整体、一撮头发...)，
  会生成一个渲染内容用的Part + 一个更大范围的MeshGroup笼子，笼子绑yaw/pitch
  的deform，Part和其他子级都挂在笼子下面跟着走。
- RigidChild：不需要自己算3D位移的刚性子级(五官这类)，纯继承父级的位移/形变。
"""

from __future__ import annotations
import io
import math
from dataclasses import dataclass
from typing import List, Optional, Tuple

import numpy as np
from PIL import Image

from obj_head_model import (
    build_head_grid, grid_to_mesh_data, rotate_project_real, build_full_topology_cage,
    build_full_topology_cage_uv, build_head_grid_cylindrical, cylindrical_grid_to_mesh_data,
    compute_ray_radius,
)
from mesh_gen import generate_mesh_from_alpha
from node_builder import new_uuid


def axis_points(n: int) -> List[float]:
    return [i / (n - 1) for i in range(n)]


def to_signed(ap: float) -> float:
    return ap * 2.0 - 1.0


def _solid_texture_bytes(rgba_color: Tuple[int, int, int, int], size: int = 256) -> bytes:
    tex = np.zeros((size, size, 4), dtype=np.uint8)
    tex[:, :, 0], tex[:, :, 1], tex[:, :, 2], tex[:, :, 3] = rgba_color
    buf = io.BytesIO()
    Image.fromarray(tex, 'RGBA').save(buf, format='PNG')
    return buf.getvalue()


def _empty_part_dict(name: str, zsort: float, mesh_verts, mesh_uvs, mesh_indices, tex_index: int) -> dict:
    return {
        "uuid": new_uuid(), "name": name, "type": "Part", "enabled": True, "zsort": zsort,
        "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False, "children": [],
        "mesh": {"verts": mesh_verts, "uvs": mesh_uvs, "indices": mesh_indices, "origin": [0.0, 0.0]},
        "textures": [tex_index, 4294967295, 4294967295],
        "blend_mode": "Normal", "tint": [1.0, 1.0, 1.0], "screenTint": [0.0, 0.0, 0.0],
        "emissionStrength": 1.0, "mask_threshold": 0.5, "opacity": 1.0, "psdLayerPath": "",
    }


def _meshgroup_dict(name: str, mesh_verts, mesh_indices, children: list) -> dict:
    return {
        "uuid": new_uuid(), "name": name, "type": "MeshGroup", "enabled": True, "zsort": 0.0,
        "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False,
        "mesh": {"verts": list(mesh_verts), "indices": list(mesh_indices), "origin": [0.0, 0.0]},
        "dynamic_deformation": False, "translate_children": True,
        "children": children,
    }


def make_group_node(name: str, children: list) -> dict:
    """普通Node分组(共享旋转轴心用，比如Neck)。"""
    return {
        "uuid": new_uuid(), "name": name, "type": "Node", "enabled": True, "zsort": 0.0,
        "transform": {"trans": [0.0, 0.0, 0.0], "rot": [0.0, 0.0, 0.0], "scale": [1.0, 1.0]},
        "lockToRoot": False, "children": children,
    }


@dataclass
class CageRegion:
    """一块OBJ射线投影驱动的形变区域。"""
    name: str                      # 笼子里渲染内容Part的名字，比如"Head:: Base"
    cage_name: str                 # MeshGroup笼子自己的名字，比如"Head:: Cage"
    x_range: Tuple[float, float]   # 内容采样范围(OBJ单位)
    y_range: Tuple[float, float]
    cols: int = 26
    rows: int = 32
    cage_cols: Optional[int] = None    # 不填就自动按cage_expand_frac比例放大
    cage_rows: Optional[int] = None
    cage_expand_frac: float = 0.12
    margin_rings: int = 2
    depth_bias_obj: float = 0.0        # OBJ单位(米)的深度修正，模拟厚度
    zsort: float = 0.0
    texture_rgba: Tuple[int, int, int, int] = (255, 220, 190, 255)  # 先用纯色测试贴图
    tex_size: int = 256
    from_back: bool = False            # True时改成从模型后方往前打射线(取背面深度)，
                                        # 给后发这类实际贴在头后方的部件用
    full_topology_cage: bool = False   # True时笼子直接用OBJ模型自己的顶点+三角面拓扑
                                        # (按z_threshold过滤)，覆盖范围比逐列射线采样更广，
                                        # 缓解大角度转动时边缘因缺乏真实几何数据而过度拉伸的问题——
                                        # 适合整个头部这种"笼子可以比内容覆盖范围大很多"的情况
    full_topology_z_threshold: float = -0.04


@dataclass
class CageBuildResult:
    part_dict: dict
    cage_dict: dict
    cage_uuid: int
    cage_obj_xyz: np.ndarray
    cage_orig_px: np.ndarray
    cage_orig_py: np.ndarray
    world_w_px: float   # 内容mesh的渲染宽高(像素)，用来给子级换算相对位置
    world_h_px: float
    tex_bytes: bytes


def build_cage_region(region: CageRegion, obj_verts: np.ndarray, obj_faces: np.ndarray,
                       scale: float, y_center_obj: float) -> CageBuildResult:
    """生成一个CageRegion对应的(内容Part + MeshGroup笼子)。"""
    grid = build_head_grid(obj_verts, obj_faces, region.x_range, region.y_range, region.cols, region.rows,
                            from_back=region.from_back)
    verts_flat, uvs_flat, indices, obj_3d_flat = grid_to_mesh_data(
        grid, scale, y_center_obj, trim_misses=True, margin_rings=1)
    obj_xyz = np.array(obj_3d_flat).reshape(-1, 3)
    obj_xyz[:, 2] += region.depth_bias_obj
    orig_px = np.array(verts_flat[0::2])
    orig_py = np.array(verts_flat[1::2])

    if region.full_topology_cage:
        cage_verts_flat, cage_indices, cage_obj_xyz, _mirror_x = build_full_topology_cage(
            obj_verts, obj_faces, scale, y_center_obj,
            z_threshold=region.full_topology_z_threshold, depth_bias_obj=region.depth_bias_obj)
        cage_orig_px = np.array(cage_verts_flat[0::2])
        cage_orig_py = np.array(cage_verts_flat[1::2])
    else:
        cage_cols = region.cage_cols or int(round(region.cols * (1 + region.cage_expand_frac)))
        cage_rows = region.cage_rows or int(round(region.rows * (1 + region.cage_expand_frac)))
        cage_grid = build_head_grid(obj_verts, obj_faces, region.x_range, region.y_range,
                                     cage_cols, cage_rows, expand_frac=region.cage_expand_frac,
                                     from_back=region.from_back)
        cage_verts_flat, _, cage_indices, cage_obj_3d_flat = grid_to_mesh_data(
            cage_grid, scale, y_center_obj, trim_misses=True, margin_rings=region.margin_rings)
        cage_obj_xyz = np.array(cage_obj_3d_flat).reshape(-1, 3)
        cage_obj_xyz[:, 2] += region.depth_bias_obj
        cage_orig_px = np.array(cage_verts_flat[0::2])
        cage_orig_py = np.array(cage_verts_flat[1::2])

    tex_bytes = _solid_texture_bytes(region.texture_rgba, region.tex_size)
    # tex_index留给调用方统一分配(要跟全局textures列表对齐)，这里先占位0，
    # 调用方拿到part_dict后自己改part_dict["textures"][0]
    part_dict = _empty_part_dict(region.name, region.zsort, verts_flat, uvs_flat, indices, 0)
    cage_dict = _meshgroup_dict(region.cage_name, cage_verts_flat, cage_indices, [part_dict])

    world_w_px = (orig_px.max() - orig_px.min()) if len(orig_px) else 0.0
    world_h_px = (orig_py.max() - orig_py.min()) if len(orig_py) else 0.0

    return CageBuildResult(
        part_dict=part_dict, cage_dict=cage_dict, cage_uuid=cage_dict["uuid"],
        cage_obj_xyz=cage_obj_xyz, cage_orig_px=cage_orig_px, cage_orig_py=cage_orig_py,
        world_w_px=world_w_px, world_h_px=world_h_px, tex_bytes=tex_bytes,
    )


def make_rigid_child_part(name: str, image_path: str, world_x: float, world_y: float,
                           parent_world_x: float, parent_world_y: float, zsort: float,
                           point_spacing: float = 20) -> Tuple[dict, bytes]:
    """不参与自己3D运算的刚性子级Part(纯继承父级)，跟node_builder._make_part_node同一套schema。"""
    img = Image.open(image_path).convert("RGBA")
    rgba = np.array(img)
    mesh = generate_mesh_from_alpha(rgba, point_spacing=point_spacing)
    x0, y0, x1, y1 = mesh.bbox
    cropped = rgba[y0:y1, x0:x1]
    crop_w, crop_h = max(x1 - x0, 1), max(y1 - y0, 1)
    full_w, full_h = rgba.shape[1], rgba.shape[0]
    uvs = list(mesh.uvs)
    for i in range(0, len(uvs), 2):
        px_ = uvs[i] * full_w
        py_ = uvs[i + 1] * full_h
        uvs[i] = (px_ - x0) / crop_w
        uvs[i + 1] = (py_ - y0) / crop_h

    buf = io.BytesIO()
    Image.fromarray(cropped, 'RGBA').save(buf, format='PNG')
    tex_bytes = buf.getvalue()

    rel_x, rel_y = world_x - parent_world_x, world_y - parent_world_y
    part_dict = _empty_part_dict(name, zsort, mesh.verts, uvs, mesh.indices, 0)
    part_dict["transform"]["trans"] = [rel_x, rel_y, 0.0]
    return part_dict, tex_bytes


def make_wrapper_meshgroup(name: str, half_w_px: float, half_h_px: float,
                            world_x: float, world_y: float,
                            parent_world_x: float, parent_world_y: float,
                            children: list) -> dict:
    """纯结构性的MeshGroup(比如Eye:: Cage)，自己不算3D位移，只是把散件包起来
    方便以后统一绑动作(比如眼球转动)。mesh只是个占位小矩形，够小孩内容用就行。"""
    verts = [-half_w_px, -half_h_px, half_w_px, -half_h_px, half_w_px, half_h_px, -half_w_px, half_h_px]
    indices = [0, 1, 2, 0, 2, 3]
    mg = _meshgroup_dict(name, verts, indices, children)
    mg["transform"]["trans"] = [world_x - parent_world_x, world_y - parent_world_y, 0.0]
    return mg


def reference_bbox_to_world(child_bbox: Tuple[float, float, float, float],
                             face_bbox: Tuple[float, float, float, float],
                             head_w_px: float, head_h_px: float) -> Tuple[float, float, float, float]:
    """把参考画布(比如已经排好版的图层草稿)里某个图层相对Face的bbox，按比例
    换算成这套OBJ头模型坐标系下的(world_x, world_y, half_w, half_h)。"""
    bx0, by0, bx1, by1 = child_bbox
    fx0, fy0, fx1, fy1 = face_bbox
    face_cx, face_cy = (fx0 + fx1) / 2.0, (fy0 + fy1) / 2.0
    face_w, face_h = fx1 - fx0, fy1 - fy0
    bcx, bcy = (bx0 + bx1) / 2.0, (by0 + by1) / 2.0
    world_x = (bcx - face_cx) / face_w * head_w_px
    world_y = (bcy - face_cy) / face_h * head_h_px
    half_w = (bx1 - bx0) / 2.0 / face_w * head_w_px
    half_h = (by1 - by0) / 2.0 / face_h * head_h_px
    return world_x, world_y, half_w, half_h


def reference_region_to_obj_range(child_bbox: Tuple[float, float, float, float],
                                   face_bbox: Tuple[float, float, float, float],
                                   head_w_px: float, head_h_px: float,
                                   scale: float, y_center_obj: float,
                                   obj_y_range: Tuple[float, float],
                                   ) -> Tuple[Tuple[float, float], Tuple[float, float]]:
    """把参考画布里某个图层的bbox，换算成OBJ单位的(x_range, y_range)，供build_head_grid采样用。
    会把y方向夹到OBJ模型自身的真实范围内(避免完全采样到模型外面打空)。"""
    world_x, world_y, half_w, half_h = reference_bbox_to_world(child_bbox, face_bbox, head_w_px, head_h_px)
    x_obj = ((world_x - half_w) / scale, (world_x + half_w) / scale)
    y_top_obj = y_center_obj - (world_y - half_h) / scale
    y_bot_obj = y_center_obj - (world_y + half_h) / scale
    y_obj = (max(y_bot_obj, obj_y_range[0]), min(y_top_obj, obj_y_range[1]))
    return x_obj, y_obj


def build_standalone_meshgroup(
    obj_verts: np.ndarray, obj_faces: np.ndarray, scale: float, y_center_obj: float,
    y_range: Tuple[float, float],
    cols: int = 26, rows: Optional[int] = None, expand_frac: float = 0.15,
    ray_radius: Optional[float] = None, radius_margin: float = 1.3,
    name: str = "Head:: Cage",
    node_type: str = "meshgroup",
    gray_rgba: Tuple[int, int, int, int] = (128, 128, 128, 255),
) -> Tuple[dict, np.ndarray, np.ndarray, np.ndarray, Optional[bytes]]:
    """
    只生成笼子本身(没有内容Part，除非node_type="part")——给"只管生成MeshGroup+
    deform，贴图/五官交给用户在Inochi Creator里手动摆"这个精简工具用。

    改用柱面展开(build_head_grid_cylindrical)取代原来只从正前方单向射线投影的
    方案：绕Y轴360°每个角度都打一条射线，网格点因此覆盖模型全部表面(含后脑勺)，
    而不再只是"正对镜头能看到的那一面"。射线起点半径(ray_radius)不传就自动按
    obj在y_range范围内的最大水平半径(乘radius_margin留一点安全余量)算出来，
    保证一定从模型外侧往轴心打。

    静止姿势(mesh.verts，Creator里没有滑动任何参数时的默认形状)固定用
    cols×rows的标准矩形铺满，不再按"有没有打中模型表面"裁剪出不规则轮廓——
    是否打中只影响这个点对应的真实3D坐标准不准，不影响静止时笼子的外形。
    真实3D坐标只用来给后续yaw/pitch/roll反推每个角度该有的deform形变。

    格子形状：不传rows时，按cols和柱面周长/高度的实际比例自动反推出能让每个
    格子长宽相等(正方形)的rows，不再是cols/rows各自随便指定、格子被拉伸成
    长方形。仍想强制指定行数(接受长方形格子)可以显式传rows覆盖自动计算。

    node_type: "meshgroup"(默认，笼子本身不显示，只用来给子级Part提供deform)
        或"part"(直接生成一个填充纯灰色、自身可见的普通Part图层，网格拓扑跟
        MeshGroup笼子完全一样，方便不需要额外子级、直接要一个能显示又能参与
        形变的图层的场景)。

    返回(node_dict, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes)。
    tex_bytes在node_type="part"时是生成的纯灰色贴图数据——调用方需要自己
    分配texture_index、把它加进全局textures列表、再回填
    node_dict["textures"][0]；node_type="meshgroup"时固定是None。
    """
    if expand_frac > 0:
        yw = (y_range[1] - y_range[0]) * expand_frac
        y_range = (y_range[0] - yw, y_range[1] + yw)

    if ray_radius is None:
        ray_radius = compute_ray_radius(obj_verts, y_range, radius_margin=radius_margin)

    circumference = 2.0 * math.pi * ray_radius
    height_obj = y_range[1] - y_range[0]
    if rows is None:
        cell_arc = circumference / max(cols - 1, 1)
        rows = max(2, int(round(height_obj / cell_arc)) + 1) if cell_arc > 0 else 2

    cage_grid = build_head_grid_cylindrical(obj_verts, obj_faces, y_range, cols, rows, ray_radius=ray_radius)

    width_px = circumference * scale
    height_px = height_obj * scale
    cage_verts_flat, cage_uvs_flat, cage_indices, cage_obj_3d_flat = cylindrical_grid_to_mesh_data(
        cage_grid, width_px, height_px)

    cage_obj_xyz = np.array(cage_obj_3d_flat).reshape(-1, 3)
    cage_orig_px = np.array(cage_verts_flat[0::2])
    cage_orig_py = np.array(cage_verts_flat[1::2])

    tex_bytes: Optional[bytes] = None
    if node_type == "part":
        tex_bytes = _solid_texture_bytes(gray_rgba, size=8)
        mg = _empty_part_dict(name, 0.0, cage_verts_flat, cage_uvs_flat, cage_indices, 0)
    else:
        mg = _meshgroup_dict(name, cage_verts_flat, cage_indices, [])

    return mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes



def build_standalone_meshgroup_full_topology(
    obj_verts: np.ndarray, obj_faces: np.ndarray, scale: float, y_center_obj: float,
    facing: str = "front", z_threshold: float = -0.04, depth_bias_obj: float = 0.0,
    name: str = "Cage", node_type: str = "meshgroup",
) -> Tuple[dict, np.ndarray, np.ndarray, np.ndarray, Optional[bytes], bool]:
    """
    全拓扑复用版的build_standalone_meshgroup：直接拿模型自己的顶点+三角面当笼子
    (不重新采样)，适合形状不规则、柱面展开会畸变的部件(一撮头发、配饰等)。

    facing="front"/"back"：见build_full_topology_cage的说明，"back"用于hair_back
    这类需要展开模型背面的部件，返回的mirror_x要传给build_yaw_pitch_param。

    跟build_standalone_meshgroup不同，目前只支持node_type="meshgroup"——"part"模式
    需要给这份不规则拓扑配一份UV才能贴图，这个还没做(复用OBJ自带UV是计划中但还没
    实现的功能)，先直接报错，不生成看起来能用实际贴图会错位的东西。

    返回(node_dict, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes固定None,
    mirror_x这个cage是否镜像了2D展开——原样转发给build_yaw_pitch_param)。
    """
    if node_type != "meshgroup":
        raise ValueError(
            "全拓扑复用法目前只支持node_type='meshgroup'；'part'模式需要给不规则拓扑"
            "配UV才能正确贴图，这个功能还没做，用柱面展开(build_standalone_meshgroup)"
            "才支持'part'模式。"
        )
    cage_verts_flat, cage_indices, cage_obj_xyz, mirror_x = build_full_topology_cage(
        obj_verts, obj_faces, scale, y_center_obj,
        z_threshold=z_threshold, depth_bias_obj=depth_bias_obj, facing=facing)
    cage_orig_px = np.array(cage_verts_flat[0::2])
    cage_orig_py = np.array(cage_verts_flat[1::2])
    mg = _meshgroup_dict(name, cage_verts_flat, cage_indices, [])
    return mg, cage_obj_xyz, cage_orig_px, cage_orig_py, None, mirror_x


def compute_turn_bindings(
    node_uuid: int, obj_xyz: np.ndarray, orig_px: np.ndarray, orig_py: np.ndarray,
    mirror_x: bool, scale: float, y_center_obj: float,
    yaw_axis: List[float], pitch_axis: List[float],
    yaw_range_deg: float, pitch_range_deg: float, pitch_flip: bool = True,
    yaw_dir: str = "both", pitch_dir: str = "both",
) -> List[dict]:
    """算一个cage在给定的yaw_axis/pitch_axis断点网格下的t.x/t.y/deform三条binding。
    yaw_axis/pitch_axis可以是新生成的，也可以是复用自某个已有参数的(绑进已有
    deformer时就是这种用法)——这个函数不关心断点是哪来的，只管按给定断点算值。

    核心公式`dx = new_px - orig_px`是个恒等式：最终渲染位置 = orig_px + dx = new_px，
    orig_px会精确抵消，所以不管orig_px用的是真实投影坐标(cylinder/full-topology)
    还是贴图UV裁剪坐标(full-topology-uv)，套用同一套公式都能得到正确的旋转结果。

    yaw_dir/pitch_dir控制这个部件是否只往一个方向动("both"/"neg"/"pos")：实现方式
    是把不允许方向的那个轴的**旋转角度钳制成0**、然后照常走完整套公式(不是把
    结果直接写成0)——钳制角度能保证跟"中心断点"用的是同一套自洽公式，不会在
    "禁用"和"启用"断点之间产生跳变。
    """
    pivot = np.array([0.0, y_center_obj, 0.0])
    values_x, values_y, deform_values = [], [], []
    isset_x, isset_y, deform_isset = [], [], []
    for ya in yaw_axis:
        ya_signed = to_signed(ya)
        yaw_active = yaw_dir == "both" or (yaw_dir == "pos" and ya_signed >= 0) or (yaw_dir == "neg" and ya_signed <= 0)
        yaw_rad = math.radians(ya_signed * yaw_range_deg) if yaw_active else 0.0
        row_x, row_y, deform_row = [], [], []
        for pa in pitch_axis:
            pa_signed = to_signed(pa)
            pitch_active = pitch_dir == "both" or (pitch_dir == "pos" and pa_signed >= 0) or (pitch_dir == "neg" and pa_signed <= 0)
            sign = -1.0 if pitch_flip else 1.0
            pitch_rad = math.radians(sign * pa_signed * pitch_range_deg) if pitch_active else 0.0
            new_xy = rotate_project_real(obj_xyz, yaw_rad, pitch_rad, 0.0, pivot)
            new_px = (-new_xy[:, 0] if mirror_x else new_xy[:, 0]) * scale
            new_py = -(new_xy[:, 1] - y_center_obj) * scale
            dx, dy = new_px - orig_px, new_py - orig_py
            rigid_x, rigid_y = float(dx.mean()), float(dy.mean())
            residual = np.stack([dx - rigid_x, dy - rigid_y], axis=-1)
            row_x.append(rigid_x)
            row_y.append(rigid_y)
            deform_row.append(residual.tolist())
        values_x.append(row_x)
        values_y.append(row_y)
        isset_x.append([True] * len(pitch_axis))
        isset_y.append([True] * len(pitch_axis))
        deform_values.append(deform_row)
        deform_isset.append([True] * len(pitch_axis))
    return [
        {"node": node_uuid, "param_name": "transform.t.x", "values": values_x,
         "isSet": isset_x, "interpolate_mode": "Linear"},
        {"node": node_uuid, "param_name": "transform.t.y", "values": values_y,
         "isSet": isset_y, "interpolate_mode": "Linear"},
        {"node": node_uuid, "param_name": "deform", "values": deform_values,
         "isSet": deform_isset, "interpolate_mode": "Linear"},
    ]


def build_standalone_meshgroup_full_topology_uv(
    obj_verts: np.ndarray, obj_faces: np.ndarray, obj_uvs: np.ndarray,
    name: str = "Cage", node_type: str = "meshgroup",
    tex_width: Optional[float] = None, tex_height: Optional[float] = None,
    gray_rgba: Tuple[int, int, int, int] = (128, 128, 128, 255),
) -> Tuple[dict, np.ndarray, np.ndarray, np.ndarray, Optional[bytes], bool]:
    """全拓扑复用+复用OBJ自带UV的版本。跟build_standalone_meshgroup_full_topology的接口
    一致(方便add_obj_deformer.py统一处理)，mirror_x固定返回False。

    静止姿势的画面位置(mesh.verts)直接映射到**贴图自己的像素坐标**(tex_width/tex_height，
    传了--texture-file的话就是那张图的真实像素宽高)——这是2D绑骨工具的通用惯例，
    图和网格天然对齐，不需要额外换算，见build_full_topology_cage_uv的详细说明。
    没传真实贴图尺寸时用一个固定的默认值(1000)，反正这种情况没有真实贴图要对齐。

    node_type="part"时会贴一份灰色占位贴图(除非传了真实贴图，由调用方在生成完node_dict
    后自行替换tex_bytes)。UV本身按这份代码库统一的约定直接用原始OBJ的v值(不翻转)。
    """
    cage_verts_flat, cage_indices, cage_obj_xyz = build_full_topology_cage_uv(
        obj_verts, obj_faces, obj_uvs, tex_width=tex_width, tex_height=tex_height)
    cage_orig_px = np.array(cage_verts_flat[0::2])
    cage_orig_py = np.array(cage_verts_flat[1::2])

    if node_type == "part":
        tex_bytes = _solid_texture_bytes(gray_rgba, size=8)
        uvs_flat = obj_uvs.reshape(-1).tolist()
        mg = _empty_part_dict(name, 0.0, cage_verts_flat, uvs_flat, cage_indices, 0)
    else:
        tex_bytes = None
        mg = _meshgroup_dict(name, cage_verts_flat, cage_indices, [])
    return mg, cage_obj_xyz, cage_orig_px, cage_orig_py, tex_bytes, False


def build_yaw_pitch_param(
    cage_bindings: List[Tuple[int, np.ndarray, np.ndarray, np.ndarray]],
    scale: float, y_center_obj: float,
    yaw_range_deg: float = 40.0, pitch_range_deg: float = 25.0,
    yaw_bp: int = 9, pitch_bp: int = 5, pitch_flip: bool = True,
    name: str = "Head:: Turn", yaw_dir: str = "both", pitch_dir: str = "both",
) -> dict:
    """给一批cage(每个是(uuid, obj_xyz真实3D坐标, orig_px, orig_py, 可选mirror_x))
    新建一个Yaw-Pitch参数，每个cage各自的t.x/t.y(刚体均值)+deform(残余形变)。"""
    yaw_axis = axis_points(yaw_bp)
    pitch_axis = axis_points(pitch_bp)
    bindings = []
    for binding_spec in cage_bindings:
        node_uuid, obj_xyz, orig_px, orig_py = binding_spec[:4]
        mirror_x = binding_spec[4] if len(binding_spec) > 4 else False
        bindings.extend(compute_turn_bindings(
            node_uuid, obj_xyz, orig_px, orig_py, mirror_x, scale, y_center_obj,
            yaw_axis, pitch_axis, yaw_range_deg, pitch_range_deg, pitch_flip,
            yaw_dir, pitch_dir,
        ))
    return {
        "uuid": new_uuid(), "name": name, "is_vec2": True,
        "min": [-1.0, -1.0], "max": [1.0, 1.0], "defaults": [0.0, 0.0],
        "axis_points": [yaw_axis, pitch_axis], "merge_mode": "Additive",
        "bindings": bindings,
    }


def bind_turn_to_existing(
    param: dict, node_uuid: int, obj_xyz: np.ndarray, orig_px: np.ndarray, orig_py: np.ndarray,
    mirror_x: bool, scale: float, y_center_obj: float,
    yaw_range_deg: float = 40.0, pitch_range_deg: float = 25.0, pitch_flip: bool = True,
    yaw_dir: str = "both", pitch_dir: str = "both",
) -> None:
    """把一个新cage的t.x/t.y/deform绑定追加进一个已有的Turn(vec2)参数里(原地修改
    param["bindings"])。断点数组直接复用param自己的axis_points——绑进已有参数时
    断点数不能由这次调用决定，必须跟这个参数已经存在的断点对齐，所以不接受
    yaw_bp/pitch_bp参数。yaw_range_deg/pitch_range_deg可以跟这个参数原本用的
    角度不一样(比如头发甩动幅度比脸大)，只要断点数对得上就行。"""
    yaw_axis, pitch_axis = param["axis_points"][0], param["axis_points"][1]
    new_bindings = compute_turn_bindings(
        node_uuid, obj_xyz, orig_px, orig_py, mirror_x, scale, y_center_obj,
        yaw_axis, pitch_axis, yaw_range_deg, pitch_range_deg, pitch_flip,
        yaw_dir, pitch_dir,
    )
    param.setdefault("bindings", []).extend(new_bindings)


def compute_roll_binding(node_uuid: int, roll_axis: List[float], roll_range_deg: float = 15.0,
                          roll_dir: str = "both") -> dict:
    """算一个节点在给定roll_axis断点下的transform.r.z binding。roll_dir同compute_turn_bindings
    的yaw_dir/pitch_dir，不在允许方向内的断点填0(不旋转)。"""
    values, isset = [], []
    for ap in roll_axis:
        ap_signed = to_signed(ap)
        active = roll_dir == "both" or (roll_dir == "pos" and ap_signed >= 0) or (roll_dir == "neg" and ap_signed <= 0)
        roll_rad = math.radians(ap_signed * roll_range_deg) if active else 0.0
        values.append([roll_rad])
        isset.append([True])
    return {"node": node_uuid, "param_name": "transform.r.z",
            "values": values, "isSet": isset, "interpolate_mode": "Linear"}


def build_roll_param(roll_node_uuid: int, roll_range_deg: float = 15.0, roll_bp: int = 5,
                      name: str = "Head:: Roll", roll_dir: str = "both") -> dict:
    """roll是纯2D旋转，不用deform模拟，直接绑外层Node分组的transform.r.z，
    精确且所有子级(不管嵌套多深)自动同步转动。"""
    roll_axis = axis_points(roll_bp)
    binding = compute_roll_binding(roll_node_uuid, roll_axis, roll_range_deg, roll_dir)
    return {
        # min/max必须用对称的[-1,1](不能用[0,1])：defaults=0.0要落在轴的正中间才能
        # 对应to_signed(0.5)=0这个断点，默认姿态才是不歪头的中立姿势；如果用[0,1]，
        # defaults=0.0会落在区间最左端，默认姿态就会变成roll_range_deg方向的歪头。
        "uuid": new_uuid(), "name": name, "is_vec2": False,
        "min": [-1.0, -1.0], "max": [1.0, 1.0], "defaults": [0.0, 0.0],
        "axis_points": [roll_axis, [0.0]], "merge_mode": "Additive",
        "bindings": [binding],
    }


def bind_roll_to_existing(param: dict, roll_node_uuid: int, roll_range_deg: float = 15.0,
                           roll_dir: str = "both") -> None:
    """把一个新节点的transform.r.z绑定追加进一个已有的Roll(非vec2)参数里(原地修改
    param["bindings"])。断点数组直接复用param自己的axis_points[0]。"""
    roll_axis = param["axis_points"][0]
    binding = compute_roll_binding(roll_node_uuid, roll_axis, roll_range_deg, roll_dir)
    param.setdefault("bindings", []).append(binding)
