# 3D_to_Live2D_equivalent — GUI

提供两套界面，共用同一份`gui_core.py`(核心计算逻辑，跟哪个界面无关)：

| | app_tk.py (桌面版，推荐先试这个) | app.py (网页版) |
|---|---|---|
| 依赖 | tkinter(Python自带)+numpy+pillow | streamlit+numpy+pillow |
| 界面 | 一个紧凑的原生窗口，不用滚动 | 浏览器网页，内容多需要上下滑动 |
| 选文件 | 系统原生"打开/另存为"对话框 | 网页上传控件+浏览器下载 |

## 安装 & 运行

### 桌面版(轻量，推荐)
```bash
pip install numpy pillow --break-system-packages   # 如果还没装
python3 app_tk.py
```
Windows/Mac的Python安装包一般自带tkinter，不用额外装。如果Linux上报"没有tkinter模块"，
装一下系统包（不是pip包）：`sudo apt install python3-tk`（Debian/Ubuntu）或对应发行版的包名。

### 网页版
```bash
pip install -r requirements.txt --break-system-packages
streamlit run app.py
```

## 文件说明
- `app_tk.py` —— 桌面版界面(tkinter)。
- `app.py` —— 网页版界面(Streamlit)。
- `gui_core.py` —— 两个界面共用的胶水层，把 `add_obj_deformer.py` 里"处理一个
  part→写入doc"这段逻辑抽成可以被GUI反复调用的函数，**没有修改任何核心文件**。
  核心作用：确保同一个模型的多个部件（比如皮肤+领口）共用同一个`y_center_obj`，
  不会像分开跑CLI那样各自算出不同基准点导致相对位置错位。
- `add_obj_deformer.py` / `obj_head_model.py` / `obj_pipeline.py` / `node_builder.py` /
  `inx_container.py` —— 原有核心逻辑，未改动，CLI用法照旧可用。

## 使用流程(两个界面操作逻辑一致)
1. 导入OBJ(必须)，可选传入已有.inx(增量往里加节点)、贴图(共享图集PNG)。
2. 如果模型轴没对齐，先在"调整初始模型"里转一下再应用（全局、一次性，会影响
   之后所有笼子构建+转动动画）。
3. 参数栏调参数、部件列表选一个部件（可以先"诊断"看这个组内部是不是碎片化）、
   右边看当前已有哪些Turn/Roll。
4. 填名字/挂载点，需要的话设置"笼子朝向"(仅影响这次怎么蒙笼子，不影响转动
   动画参照系，hair_back/侧面部件用这个)，选Turn/Roll是新建还是绑定进已有的，
   点"确认写入这个部件"。
5. 对同一个模型的每个部件重复第3-4步。
6. 完成后保存/下载生成的.inx文件。

## 已知限制(跟核心代码现状一致，不是GUI遗漏)
- `full-topology-uv`模式不生成roll(核心逻辑本身跳过，需要在Inochi Creator里手动加)。
- `full-topology`(正交投影)不支持`node_type=part`。
- 按UV island分组(`--group-by island`)这个CLI选项还没接入主流程，GUI暂不提供，
  "诊断"按钮可以看到island拆分结果，但目前不能直接从某个island生成节点。
