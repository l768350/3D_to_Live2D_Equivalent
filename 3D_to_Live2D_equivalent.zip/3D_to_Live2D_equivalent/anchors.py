# -*- coding: utf-8 -*-
"""占位stub：仅为满足node_builder.py的import依赖，主流程(add_obj_deformer.py)
不会用到这里的真实锚点系统实现，属于旧版pipeline的残留依赖。"""
from dataclasses import dataclass
from typing import Tuple


@dataclass
class AnchorDef:
    group_path: Tuple[str, ...]
    depth: float = 0.0


def get_anchor(name: str) -> AnchorDef:
    raise NotImplementedError("anchors.py是占位stub，没有实现真实的锚点系统")
