# -*- coding: utf-8 -*-
"""
inx_container.py
------------------
Inochi2D .inx/.inp 文件的二进制容器格式读写，按官方规格实现
(https://github.com/Inochi2D/inochi2d/wiki/INP-Data-Interchange-Format)，
读取部分已用真实的Inochi Creator导出文件验证过。

容器格式(大端序):
  8 bytes   "TRNSRTS\0"        magic
  4 bytes   JSON payload 长度
  N bytes   JSON payload (UTF-8)
  8 bytes   "TEX_SECT"
  4 bytes   贴图数量
  ...       每张贴图: 4字节长度 + 1字节编码类型(0=PNG/1=TGA/2=BC7) + 数据
  8 bytes   "EXT_SECT" (可选，我们不生成)
"""

from __future__ import annotations
import struct
import json
from dataclasses import dataclass, field
from typing import List

MAGIC = b"TRNSRTS\0"
TEX_SECT = b"TEX_SECT"
EXT_SECT = b"EXT_SECT"


@dataclass
class TextureEntry:
    data: bytes          # 编码后的图片数据(比如PNG字节流)
    encoding: int = 0    # 0 = PNG


@dataclass
class InxDocument:
    payload: dict
    textures: List[TextureEntry] = field(default_factory=list)


def read_inx(path: str) -> InxDocument:
    with open(path, "rb") as f:
        data = f.read()

    if data[0:8] != MAGIC:
        raise ValueError(f"{path} 不是有效的 Inochi2D 文件(magic不匹配)")

    json_len = struct.unpack(">I", data[8:12])[0]
    payload = json.loads(data[12:12 + json_len].decode("utf-8"))

    offset = 12 + json_len
    textures = []
    if data[offset:offset + 8] == TEX_SECT:
        offset += 8
        tex_count = struct.unpack(">I", data[offset:offset + 4])[0]
        offset += 4
        for _ in range(tex_count):
            tex_len = struct.unpack(">I", data[offset:offset + 4])[0]
            offset += 4
            encoding = data[offset]
            offset += 1
            tex_data = data[offset:offset + tex_len]
            offset += tex_len
            textures.append(TextureEntry(data=tex_data, encoding=encoding))

    return InxDocument(payload=payload, textures=textures)


def write_inx(path: str, doc: InxDocument):
    json_bytes = json.dumps(doc.payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

    out = bytearray()
    out += MAGIC
    out += struct.pack(">I", len(json_bytes))
    out += json_bytes

    out += TEX_SECT
    out += struct.pack(">I", len(doc.textures))
    for tex in doc.textures:
        out += struct.pack(">I", len(tex.data))
        out += bytes([tex.encoding])
        out += tex.data

    with open(path, "wb") as f:
        f.write(bytes(out))
